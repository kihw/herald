package models

import "time"

// Meta-Game Analytics Models

// PatchTrends represents meta trends for a specific game patch
type PatchTrends struct {
	Patch          string          `json:"patch"`
	Region         string          `json:"region"`
	AnalysisDate   time.Time       `json:"analysis_date"`
	ChampionTrends []ChampionTrend `json:"champion_trends"`
	ItemTrends     []ItemTrend     `json:"item_trends"`
	BanTrends      []BanTrend      `json:"ban_trends"`
}

// ChampionTrend represents champion trend data
type ChampionTrend struct {
	ChampionID   int     `json:"champion_id"`
	ChampionName string  `json:"champion_name"`
	TotalPicks   int     `json:"total_picks"`
	WinRate      float64 `json:"win_rate"`
	AvgImpact    float64 `json:"avg_impact"`
	TrendChange  float64 `json:"trend_change"`  // Compared to previous patch
}

// ItemTrend represents item usage trends
type ItemTrend struct {
	ItemID       int     `json:"item_id"`
	ItemName     string  `json:"item_name"`
	PickRate     float64 `json:"pick_rate"`
	WinRate      float64 `json:"win_rate"`
	TrendChange  float64 `json:"trend_change"`
	PopularRoles []string `json:"popular_roles"`
}

// BanTrend represents champion ban trends
type BanTrend struct {
	ChampionID   int     `json:"champion_id"`
	ChampionName string  `json:"champion_name"`
	BanRate      float64 `json:"ban_rate"`
	TrendChange  float64 `json:"trend_change"`
	BanPriority  int     `json:"ban_priority"` // 1-5 (first ban vs later bans)
}

// EmergingChampion represents champions gaining popularity
type EmergingChampion struct {
	ChampionID      int     `json:"champion_id"`
	ChampionName    string  `json:"champion_name"`
	CurrentPicks    int     `json:"current_picks"`
	CurrentWinRate  float64 `json:"current_win_rate"`
	CurrentKDA      float64 `json:"current_kda"`
	PreviousPicks   int     `json:"previous_picks"`
	PreviousWinRate float64 `json:"previous_win_rate"`
	PickRateChange  float64 `json:"pick_rate_change"`    // Percentage change
	WinRateChange   float64 `json:"win_rate_change"`     // Absolute change
	EmergenceScore  float64 `json:"emergence_score"`     // 0-100 composite score
	TrendDirection  string  `json:"trend_direction"`     // "strongly_rising", "rising", "stable", "declining"
}

// TeamSynergy represents champion synergy analysis
type TeamSynergy struct {
	Champion1ID    int     `json:"champion1_id"`
	Champion1Name  string  `json:"champion1_name"`
	Champion2ID    int     `json:"champion2_id"`
	Champion2Name  string  `json:"champion2_name"`
	GamesTogether  int     `json:"games_together"`
	WinRate        float64 `json:"win_rate"`
	AvgImpact      float64 `json:"avg_impact"`
	SynergyScore   float64 `json:"synergy_score"`   // 0-100 composite score
	Confidence     float64 `json:"confidence"`      // 0-1 based on sample size
	SynergyType    string  `json:"synergy_type"`    // "lane", "team_fight", "utility"
}

// ItemMeta represents item meta analysis
type ItemMeta struct {
	Region         string          `json:"region"`
	AnalysisPeriod int             `json:"analysis_period_days"`
	LastUpdated    time.Time       `json:"last_updated"`
	PopularBuilds  []ItemBuild     `json:"popular_builds"`
	ItemWinRates   []ItemWinRate   `json:"item_win_rates"`
	TrendingItems  []TrendingItem  `json:"trending_items"`
}

// ItemBuild represents popular item build sequences
type ItemBuild struct {
	BuildID       string    `json:"build_id"`
	ChampionID    int       `json:"champion_id"`
	ChampionName  string    `json:"champion_name"`
	ItemSequence  []int     `json:"item_sequence"`    // Order of item IDs
	ItemNames     []string  `json:"item_names"`       
	PickRate      float64   `json:"pick_rate"`
	WinRate       float64   `json:"win_rate"`
	AvgGameTime   float64   `json:"avg_game_time"`    // When build is completed
	Role          string    `json:"role"`
	Confidence    float64   `json:"confidence"`
}

// ItemWinRate represents win rate data for individual items
type ItemWinRate struct {
	ItemID       int     `json:"item_id"`
	ItemName     string  `json:"item_name"`
	TotalGames   int     `json:"total_games"`
	WinRate      float64 `json:"win_rate"`
	PickRate     float64 `json:"pick_rate"`
	AvgPosition  float64 `json:"avg_position"`  // Average position in build order
	BestRoles    []string `json:"best_roles"`
}

// TrendingItem represents items trending up or down
type TrendingItem struct {
	ItemID        int     `json:"item_id"`
	ItemName      string  `json:"item_name"`
	CurrentPicks  int     `json:"current_picks"`
	PreviousPicks int     `json:"previous_picks"`
	PickChange    float64 `json:"pick_change"`     // Percentage change
	WinRateChange float64 `json:"win_rate_change"` // Absolute change
	TrendScore    float64 `json:"trend_score"`     // 0-100 composite
	TrendType     string  `json:"trend_type"`      // "rising", "falling", "stable"
}

// RankCorrelation represents champion performance by rank
type RankCorrelation struct {
	ChampionID   int     `json:"champion_id"`
	ChampionName string  `json:"champion_name"`
	Tier         string  `json:"tier"`         // "IRON", "BRONZE", etc.
	RankTier     string  `json:"rank_tier"`    // "I", "II", "III", "IV"
	GamesPlayed  int     `json:"games_played"`
	WinRate      float64 `json:"win_rate"`
	AvgImpact    float64 `json:"avg_impact"`
	RankScore    float64 `json:"rank_score"`   // Weighted performance score
}

// Pattern Detection Models

// GamePattern represents detected gameplay patterns
type GamePattern struct {
	PatternID     string    `json:"pattern_id"`
	PatternType   string    `json:"pattern_type"`    // "victory", "defeat", "timing", "style"
	UserID        int       `json:"user_id"`
	Description   string    `json:"description"`
	Frequency     float64   `json:"frequency"`       // How often pattern occurs (0-1)
	Confidence    float64   `json:"confidence"`      // Statistical confidence (0-1)
	ImpactScore   float64   `json:"impact_score"`    // Impact on game outcome (0-100)
	FirstDetected time.Time `json:"first_detected"`
	LastSeen      time.Time `json:"last_seen"`
	Conditions    []string  `json:"conditions"`      // Conditions that trigger pattern
	Suggestions   []string  `json:"suggestions"`     // Actionable suggestions
}

// TimingPattern represents optimal timing patterns
type TimingPattern struct {
	PatternName   string  `json:"pattern_name"`
	GamePhase     string  `json:"game_phase"`      // "early", "mid", "late"
	OptimalTiming float64 `json:"optimal_timing"`  // Minutes into game
	WinRate       float64 `json:"win_rate"`        // Win rate when executed at optimal timing
	Frequency     float64 `json:"frequency"`       // How often user executes at optimal timing
	Description   string  `json:"description"`
	Improvement   string  `json:"improvement"`     // What to improve
}

// PerformanceAnomaly represents detected performance anomalies
type PerformanceAnomaly struct {
	AnomalyID     string    `json:"anomaly_id"`
	UserID        int       `json:"user_id"`
	AnomalyType   string    `json:"anomaly_type"`    // "performance_spike", "performance_drop", "consistency_issue"
	Severity      string    `json:"severity"`        // "low", "medium", "high", "critical"
	DetectedAt    time.Time `json:"detected_at"`
	Period        string    `json:"period"`          // Time period affected
	AffectedMetric string   `json:"affected_metric"` // Which metric is anomalous
	ExpectedValue float64   `json:"expected_value"`
	ActualValue   float64   `json:"actual_value"`
	DeviationScore float64  `json:"deviation_score"` // How far from normal (0-100)
	PossibleCauses []string `json:"possible_causes"`
	Recommendations []string `json:"recommendations"`
}

// PlayStyle represents user's detected play style
type PlayStyle struct {
	UserID          int       `json:"user_id"`
	PrimaryStyle    string    `json:"primary_style"`    // "aggressive", "defensive", "balanced", "supportive"
	SecondaryStyle  string    `json:"secondary_style"`
	Confidence      float64   `json:"confidence"`       // 0-1
	StyleMetrics    map[string]float64 `json:"style_metrics"` // Various style indicators
	Adaptability    float64   `json:"adaptability"`     // How well user adapts style (0-100)
	ConsistencyScore float64  `json:"consistency_score"` // Style consistency (0-100)
	OptimalConditions []string `json:"optimal_conditions"` // When this style works best
	WeakAgainst     []string  `json:"weak_against"`     // What counters this style
	LastAnalyzed    time.Time `json:"last_analyzed"`
}

// Machine Learning & Prediction Models

// PerformancePrediction represents ML-based performance predictions
type PerformancePrediction struct {
	UserID            int                    `json:"user_id"`
	PredictionID      string                 `json:"prediction_id"`
	PredictionType    string                 `json:"prediction_type"`    // "winrate", "rank", "performance"
	TimeHorizon       int                    `json:"time_horizon"`       // Days into future
	CurrentBaseline   float64                `json:"current_baseline"`   // Current performance
	PredictedValue    float64                `json:"predicted_value"`    // Predicted performance
	Confidence        float64                `json:"confidence"`         // Prediction confidence (0-1)
	FactorsAnalyzed   []PredictionFactor     `json:"factors_analyzed"`
	Scenarios         []PredictionScenario   `json:"scenarios"`          // Different outcome scenarios
	Recommendations   []string               `json:"recommendations"`
	CreatedAt         time.Time              `json:"created_at"`
	ValidUntil        time.Time              `json:"valid_until"`
}

// PredictionFactor represents factors influencing predictions
type PredictionFactor struct {
	FactorName   string  `json:"factor_name"`
	Impact       float64 `json:"impact"`        // Impact weight (-100 to +100)
	CurrentValue float64 `json:"current_value"`
	Trend        string  `json:"trend"`         // "improving", "declining", "stable"
	Description  string  `json:"description"`
}

// PredictionScenario represents different prediction scenarios
type PredictionScenario struct {
	ScenarioName    string  `json:"scenario_name"`
	Probability     float64 `json:"probability"`     // 0-1
	PredictedOutcome float64 `json:"predicted_outcome"`
	RequiredChanges  []string `json:"required_changes"` // What needs to change for this scenario
	Description      string  `json:"description"`
}

// ChampionRecommendation represents optimal champion recommendations
type ChampionRecommendation struct {
	UserID           int     `json:"user_id"`
	ChampionID       int     `json:"champion_id"`
	ChampionName     string  `json:"champion_name"`
	RecommendationType string `json:"recommendation_type"` // "team_comp", "meta", "personal_strength"
	FitScore         float64 `json:"fit_score"`           // How well champion fits (0-100)
	ExpectedWinRate  float64 `json:"expected_win_rate"`   // Predicted win rate with this champion
	Reasoning        []string `json:"reasoning"`          // Why this champion is recommended
	TeamContext      string  `json:"team_context"`       // Team composition context
	CounterPicks     []int   `json:"counter_picks"`      // Champions that counter this pick
	Synergies        []int   `json:"synergies"`          // Champions that synergize
	Confidence       float64 `json:"confidence"`         // Recommendation confidence (0-1)
	MetaRelevance    float64 `json:"meta_relevance"`     // Current meta relevance (0-100)
}

// MatchPrediction represents real-time match outcome prediction
type MatchPrediction struct {
	MatchID          string             `json:"match_id"`
	UserID           int                `json:"user_id"`
	TeamComposition  []int              `json:"team_composition"`    // Champion IDs for user's team
	EnemyComposition []int              `json:"enemy_composition"`   // Champion IDs for enemy team
	PredictedOutcome string             `json:"predicted_outcome"`   // "win", "loss"
	WinProbability   float64            `json:"win_probability"`     // 0-1
	KeyFactors       []PredictionFactor `json:"key_factors"`
	CriticalPhases   []string           `json:"critical_phases"`     // When outcome will likely be decided
	StrategicTips    []string           `json:"strategic_tips"`      // Real-time strategic advice
	UpdatedAt        time.Time          `json:"updated_at"`
}

// ImprovementRoadmap represents personalized improvement plan
type ImprovementRoadmap struct {
	UserID          int                  `json:"user_id"`
	RoadmapID       string               `json:"roadmap_id"`
	CurrentLevel    string               `json:"current_level"`      // Current skill level assessment
	TargetLevel     string               `json:"target_level"`       // Target skill level
	EstimatedTimeframe int               `json:"estimated_timeframe"` // Days to reach target
	Milestones      []ImprovementMilestone `json:"milestones"`
	WeeklyGoals     []WeeklyGoal         `json:"weekly_goals"`
	TrackingMetrics []string             `json:"tracking_metrics"`    // Metrics to track progress
	CreatedAt       time.Time            `json:"created_at"`
	LastUpdated     time.Time            `json:"last_updated"`
	Progress        float64              `json:"progress"`            // 0-100 completion percentage
}

// ImprovementMilestone represents a milestone in the improvement roadmap
type ImprovementMilestone struct {
	MilestoneID   string    `json:"milestone_id"`
	Title         string    `json:"title"`
	Description   string    `json:"description"`
	TargetValue   float64   `json:"target_value"`
	CurrentValue  float64   `json:"current_value"`
	IsCompleted   bool      `json:"is_completed"`
	CompletedAt   *time.Time `json:"completed_at,omitempty"`
	EstimatedDays int       `json:"estimated_days"`
	Priority      int       `json:"priority"`       // 1-5 priority level
}

// WeeklyGoal represents weekly improvement goals
type WeeklyGoal struct {
	GoalID      string    `json:"goal_id"`
	WeekNumber  int       `json:"week_number"`
	Title       string    `json:"title"`
	Description string    `json:"description"`
	TargetValue float64   `json:"target_value"`
	CurrentValue float64  `json:"current_value"`
	IsCompleted bool      `json:"is_completed"`
	Progress    float64   `json:"progress"`       // 0-100
	DueDate     time.Time `json:"due_date"`
}

// ProgressionPlateau represents detected progression plateaus
type ProgressionPlateau struct {
	UserID          int       `json:"user_id"`
	PlateauID       string    `json:"plateau_id"`
	MetricAffected  string    `json:"metric_affected"`  // Which metric is plateauing
	PlateauStart    time.Time `json:"plateau_start"`
	Duration        int       `json:"duration"`         // Days of plateau
	Severity        string    `json:"severity"`         // "mild", "moderate", "severe"
	PossibleCauses  []string  `json:"possible_causes"`
	BreakthroughTips []string `json:"breakthrough_tips"`
	EstimatedBreakthrough int `json:"estimated_breakthrough"` // Days to break through
	Confidence      float64   `json:"confidence"`       // 0-1
}

// Multi-Player Comparative Analytics

// PlayerComparison represents detailed comparison between players
type PlayerComparison struct {
	UserID          int                    `json:"user_id"`
	ComparisonID    string                 `json:"comparison_id"`
	ComparisonType  string                 `json:"comparison_type"`  // "similar_rank", "friend", "target"
	TargetPlayerID  int                    `json:"target_player_id"`
	TargetPlayerName string                `json:"target_player_name"`
	MetricComparisons []MetricComparison   `json:"metric_comparisons"`
	OverallScore    ComparisonScore        `json:"overall_score"`
	StrengthsAdvantages []string           `json:"strengths_advantages"`  // Where user is better
	ImprovementAreas []string             `json:"improvement_areas"`     // Where user can improve
	ActionableInsights []string           `json:"actionable_insights"`
	CreatedAt       time.Time              `json:"created_at"`
}

// MetricComparison represents comparison of a specific metric
type MetricComparison struct {
	MetricName     string  `json:"metric_name"`
	UserValue      float64 `json:"user_value"`
	TargetValue    float64 `json:"target_value"`
	Difference     float64 `json:"difference"`      // Absolute difference
	PercentageDiff float64 `json:"percentage_diff"` // Percentage difference
	ComparisonType string  `json:"comparison_type"` // "better", "worse", "similar"
	Significance   string  `json:"significance"`    // "minor", "moderate", "major"
}

// ComparisonScore represents overall comparison scoring
type ComparisonScore struct {
	OverallRating  float64 `json:"overall_rating"`  // 0-100 how user compares overall
	SkillGap       float64 `json:"skill_gap"`       // Estimated skill difference
	TimeToMatch    int     `json:"time_to_match"`   // Days to reach target level
	Confidence     float64 `json:"confidence"`      // Confidence in assessment
}

// RegionalBenchmark represents performance benchmarks by region/rank
type RegionalBenchmark struct {
	Region          string             `json:"region"`
	Tier            string             `json:"tier"`
	Division        string             `json:"division"`
	MetricBenchmarks []MetricBenchmark `json:"metric_benchmarks"`
	PlayerCount     int                `json:"player_count"`     // Sample size
	LastUpdated     time.Time          `json:"last_updated"`
}

// MetricBenchmark represents benchmark values for specific metrics
type MetricBenchmark struct {
	MetricName   string  `json:"metric_name"`
	Average      float64 `json:"average"`
	Median       float64 `json:"median"`
	Top10Percent float64 `json:"top_10_percent"`
	Top25Percent float64 `json:"top_25_percent"`
	Bottom25Percent float64 `json:"bottom_25_percent"`
	StandardDeviation float64 `json:"standard_deviation"`
}

// CustomRanking represents custom player rankings
type CustomRanking struct {
	RankingID    string             `json:"ranking_id"`
	RankingName  string             `json:"ranking_name"`
	Criteria     []RankingCriteria  `json:"criteria"`
	PlayerRanks  []PlayerRank       `json:"player_ranks"`
	Region       string             `json:"region"`
	TimeFrame    string             `json:"time_frame"`
	CreatedBy    int                `json:"created_by"`
	IsPublic     bool               `json:"is_public"`
	CreatedAt    time.Time          `json:"created_at"`
	LastUpdated  time.Time          `json:"last_updated"`
}

// RankingCriteria represents criteria for custom rankings
type RankingCriteria struct {
	MetricName string  `json:"metric_name"`
	Weight     float64 `json:"weight"`      // 0-1 weight in final ranking
	Direction  string  `json:"direction"`   // "higher_better" or "lower_better"
}

// PlayerRank represents a player's position in a custom ranking
type PlayerRank struct {
	PlayerID    int     `json:"player_id"`
	PlayerName  string  `json:"player_name"`
	Rank        int     `json:"rank"`
	Score       float64 `json:"score"`
	MetricValues map[string]float64 `json:"metric_values"`
}

// ProgressionMetrics represents progression tracking metrics
type ProgressionMetrics struct {
	UserID           int       `json:"user_id"`
	CurrentRank      string    `json:"current_rank"`
	PreviousRank     string    `json:"previous_rank"`
	RankProgress     float64   `json:"rank_progress"`     // Progress within current rank (0-100)
	TrendDirection   string    `json:"trend_direction"`   // "improving", "declining", "stable"
	VelocityScore    float64   `json:"velocity_score"`    // Rate of improvement
	ConsistencyScore float64   `json:"consistency_score"` // Performance consistency
	PeakPerformance  time.Time `json:"peak_performance"`  // When user performed best
	LastImprovement  time.Time `json:"last_improvement"`  // Last significant improvement
	ProjectedRank    string    `json:"projected_rank"`    // Projected rank in 30 days
	Confidence       float64   `json:"confidence"`        // Projection confidence
}

// SmurfDetection represents smurf/alt account detection
type SmurfDetection struct {
	UserID           int       `json:"user_id"`
	SmurfProbability float64   `json:"smurf_probability"` // 0-1 probability of being smurf
	Indicators       []string  `json:"indicators"`        // Indicators suggesting smurf
	TrueSkillEst     string    `json:"true_skill_est"`    // Estimated true skill level
	Confidence       float64   `json:"confidence"`        // Detection confidence
	AccountAge       int       `json:"account_age"`       // Days since account creation
	RankClimbSpeed   float64   `json:"rank_climb_speed"`  // Rate of rank climbing
	PerformanceSpikes []time.Time `json:"performance_spikes"`
	DetectedAt       time.Time `json:"detected_at"`
}
