package services

import (
	"database/sql"
	"fmt"
	"log"
	"math"
	"sort"
	"time"

	"lol-match-exporter/internal/models"
)

// PatternDetectionService handles gameplay pattern analysis
type PatternDetectionService struct {
	db *sql.DB
}

// NewPatternDetectionService creates a new pattern detection service
func NewPatternDetectionService(db *sql.DB) *PatternDetectionService {
	return &PatternDetectionService{
		db: db,
	}
}

// DetectVictoryPatterns identifies patterns that lead to victories
func (p *PatternDetectionService) DetectVictoryPatterns(userID int) ([]models.GamePattern, error) {
	log.Printf("🔍 Detecting victory patterns for user %d", userID)

	// Get recent match data
	matches, err := p.getUserMatches(userID, 60) // Last 60 days
	if err != nil {
		return nil, fmt.Errorf("failed to get user matches: %w", err)
	}

	if len(matches) < 20 {
		return nil, fmt.Errorf("insufficient match data for pattern analysis")
	}

	var patterns []models.GamePattern

	// Detect early game dominance pattern
	earlyPattern := p.detectEarlyGamePattern(matches, userID)
	if earlyPattern != nil {
		patterns = append(patterns, *earlyPattern)
	}

	// Detect late game scaling pattern
	latePattern := p.detectLateGamePattern(matches, userID)
	if latePattern != nil {
		patterns = append(patterns, *latePattern)
	}

	// Detect vision control pattern
	visionPattern := p.detectVisionPattern(matches, userID)
	if visionPattern != nil {
		patterns = append(patterns, *visionPattern)
	}

	// Detect objective control pattern
	objectivePattern := p.detectObjectivePattern(matches, userID)
	if objectivePattern != nil {
		patterns = append(patterns, *objectivePattern)
	}

	// Detect champion-specific patterns
	championPatterns := p.detectChampionPatterns(matches, userID)
	patterns = append(patterns, championPatterns...)

	log.Printf("✅ Detected %d victory patterns", len(patterns))
	return patterns, nil
}

// DetectDefeatPatterns identifies patterns that lead to defeats
func (p *PatternDetectionService) DetectDefeatPatterns(userID int) ([]models.GamePattern, error) {
	log.Printf("🔍 Detecting defeat patterns for user %d", userID)

	matches, err := p.getUserMatches(userID, 60)
	if err != nil {
		return nil, fmt.Errorf("failed to get user matches: %w", err)
	}

	var patterns []models.GamePattern

	// Detect feeding pattern
	feedingPattern := p.detectFeedingPattern(matches, userID)
	if feedingPattern != nil {
		patterns = append(patterns, *feedingPattern)
	}

	// Detect late game throw pattern
	throwPattern := p.detectLateGameThrowPattern(matches, userID)
	if throwPattern != nil {
		patterns = append(patterns, *throwPattern)
	}

	// Detect poor CS pattern
	csPattern := p.detectPoorCSPattern(matches, userID)
	if csPattern != nil {
		patterns = append(patterns, *csPattern)
	}

	// Detect tilt pattern
	tiltPattern := p.detectTiltPattern(matches, userID)
	if tiltPattern != nil {
		patterns = append(patterns, *tiltPattern)
	}

	log.Printf("✅ Detected %d defeat patterns", len(patterns))
	return patterns, nil
}

// AnalyzeOptimalTiming identifies optimal timing for key game actions
func (p *PatternDetectionService) AnalyzeOptimalTiming(userID int) ([]models.TimingPattern, error) {
	log.Printf("⏰ Analyzing optimal timing patterns for user %d", userID)

	matches, err := p.getUserMatches(userID, 45)
	if err != nil {
		return nil, fmt.Errorf("failed to get user matches: %w", err)
	}

	var patterns []models.TimingPattern

	// Analyze first blood timing
	fbPattern := p.analyzeFirstBloodTiming(matches)
	if fbPattern != nil {
		patterns = append(patterns, *fbPattern)
	}

	// Analyze objective timing
	dragonPattern := p.analyzeDragonTiming(matches)
	if dragonPattern != nil {
		patterns = append(patterns, *dragonPattern)
	}

	// Analyze recall timing
	recallPattern := p.analyzeRecallTiming(matches)
	if recallPattern != nil {
		patterns = append(patterns, *recallPattern)
	}

	// Analyze team fight timing
	teamfightPattern := p.analyzeTeamfightTiming(matches)
	if teamfightPattern != nil {
		patterns = append(patterns, *teamfightPattern)
	}

	log.Printf("✅ Analyzed %d timing patterns", len(patterns))
	return patterns, nil
}

// DetectPerformanceAnomalies identifies unusual performance spikes or drops
func (p *PatternDetectionService) DetectPerformanceAnomalies(userID int) ([]models.PerformanceAnomaly, error) {
	log.Printf("📊 Detecting performance anomalies for user %d", userID)

	// Get performance metrics over time
	metrics, err := p.getPerformanceMetricsTimeline(userID, 90)
	if err != nil {
		return nil, fmt.Errorf("failed to get performance metrics: %w", err)
	}

	var anomalies []models.PerformanceAnomaly

	// Analyze KDA anomalies
	kdaAnomalies := p.detectKDAAnomalies(metrics, userID)
	anomalies = append(anomalies, kdaAnomalies...)

	// Analyze CS anomalies
	csAnomalies := p.detectCSAnomalies(metrics, userID)
	anomalies = append(anomalies, csAnomalies...)

	// Analyze win rate anomalies
	winrateAnomalies := p.detectWinRateAnomalies(metrics, userID)
	anomalies = append(anomalies, winrateAnomalies...)

	// Analyze damage anomalies
	damageAnomalies := p.detectDamageAnomalies(metrics, userID)
	anomalies = append(anomalies, damageAnomalies...)

	log.Printf("✅ Detected %d performance anomalies", len(anomalies))
	return anomalies, nil
}

// AnalyzePlayStyle determines user's dominant play style
func (p *PatternDetectionService) AnalyzePlayStyle(userID int) (*models.PlayStyle, error) {
	log.Printf("🎯 Analyzing play style for user %d", userID)

	matches, err := p.getUserMatches(userID, 60)
	if err != nil {
		return nil, fmt.Errorf("failed to get user matches: %w", err)
	}

	if len(matches) < 15 {
		return nil, fmt.Errorf("insufficient data for play style analysis")
	}

	// Calculate style metrics
	styleMetrics := p.calculateStyleMetrics(matches)

	// Determine primary style
	primaryStyle := p.determinePrimaryStyle(styleMetrics)
	secondaryStyle := p.determineSecondaryStyle(styleMetrics, primaryStyle)

	// Calculate confidence and consistency
	confidence := p.calculateStyleConfidence(styleMetrics, primaryStyle)
	consistency := p.calculateStyleConsistency(matches, primaryStyle)
	adaptability := p.calculateAdaptability(matches)

	// Get style-specific insights
	optimalConditions := p.getOptimalConditions(primaryStyle, styleMetrics)
	weakAgainst := p.getWeaknesses(primaryStyle, matches)

	playStyle := &models.PlayStyle{
		UserID:            userID,
		PrimaryStyle:      primaryStyle,
		SecondaryStyle:    secondaryStyle,
		Confidence:        confidence,
		StyleMetrics:      styleMetrics,
		Adaptability:      adaptability,
		ConsistencyScore:  consistency,
		OptimalConditions: optimalConditions,
		WeakAgainst:       weakAgainst,
		LastAnalyzed:      time.Now(),
	}

	log.Printf("✅ Analyzed play style: %s/%s (confidence: %.2f)", primaryStyle, secondaryStyle, confidence)
	return playStyle, nil
}

// Private helper methods

func (p *PatternDetectionService) getUserMatches(userID int, days int) ([]map[string]interface{}, error) {
	query := `
		SELECT match_id, game_creation, game_duration, win, 
			   kills, deaths, assists, cs_per_min, gold_per_min,
			   damage_to_champions, vision_score, champion_id, champion_name,
			   role, first_blood_kill, first_blood_assist, first_tower_kill
		FROM matches 
		WHERE user_id = ? AND game_creation >= ?
		ORDER BY game_creation DESC
	`

	startTime := time.Now().AddDate(0, 0, -days).Unix() * 1000
	rows, err := p.db.Query(query, userID, startTime)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var matches []map[string]interface{}
	for rows.Next() {
		match := make(map[string]interface{})
		var matchID string
		var gameCreation int64
		var gameDuration, win, kills, deaths, assists int
		var csPerMin, goldPerMin, damageToChampions, visionScore float64
		var championID int
		var championName, role string
		var firstBloodKill, firstBloodAssist, firstTowerKill bool

		err := rows.Scan(
			&matchID, &gameCreation, &gameDuration, &win,
			&kills, &deaths, &assists, &csPerMin, &goldPerMin,
			&damageToChampions, &visionScore, &championID, &championName,
			&role, &firstBloodKill, &firstBloodAssist, &firstTowerKill,
		)
		if err != nil {
			continue
		}

		match["match_id"] = matchID
		match["game_creation"] = gameCreation
		match["game_duration"] = gameDuration
		match["win"] = win == 1
		match["kills"] = kills
		match["deaths"] = deaths
		match["assists"] = assists
		match["cs_per_min"] = csPerMin
		match["gold_per_min"] = goldPerMin
		match["damage_to_champions"] = damageToChampions
		match["vision_score"] = visionScore
		match["champion_id"] = championID
		match["champion_name"] = championName
		match["role"] = role
		match["first_blood_kill"] = firstBloodKill
		match["first_blood_assist"] = firstBloodAssist
		match["first_tower_kill"] = firstTowerKill

		matches = append(matches, match)
	}

	return matches, nil
}

func (p *PatternDetectionService) detectEarlyGamePattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// Count games where user got early advantages and won
	earlyAdvantageWins := 0
	totalEarlyAdvantages := 0

	for _, match := range matches {
		hasEarlyAdvantage := match["first_blood_kill"].(bool) || 
						   match["first_blood_assist"].(bool) || 
						   match["first_tower_kill"].(bool)
		
		if hasEarlyAdvantage {
			totalEarlyAdvantages++
			if match["win"].(bool) {
				earlyAdvantageWins++
			}
		}
	}

	if totalEarlyAdvantages < 5 {
		return nil // Not enough data
	}

	frequency := float64(totalEarlyAdvantages) / float64(len(matches))
	winRate := float64(earlyAdvantageWins) / float64(totalEarlyAdvantages)

	if frequency < 0.2 || winRate < 0.6 {
		return nil // Pattern not significant
	}

	return &models.GamePattern{
		PatternID:     p.generatePatternID(userID, "early_game"),
		PatternType:   "victory",
		UserID:        userID,
		Description:   fmt.Sprintf("High win rate (%.1f%%) when securing early game advantages", winRate*100),
		Frequency:     frequency,
		Confidence:    p.calculateConfidence(totalEarlyAdvantages),
		ImpactScore:   winRate * 100,
		FirstDetected: time.Now().AddDate(0, 0, -30),
		LastSeen:      time.Now(),
		Conditions:    []string{"First blood", "First tower", "Early kills"},
		Suggestions:   []string{"Focus on early game aggression", "Ward enemy jungle early", "Coordinate with jungler"},
	}
}

func (p *PatternDetectionService) detectLateGamePattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// Analyze win rate in long games (>35 minutes)
	longGameWins := 0
	totalLongGames := 0

	for _, match := range matches {
		gameDuration := match["game_duration"].(int)
		if gameDuration > 35*60 { // 35 minutes in seconds
			totalLongGames++
			if match["win"].(bool) {
				longGameWins++
			}
		}
	}

	if totalLongGames < 8 {
		return nil
	}

	frequency := float64(totalLongGames) / float64(len(matches))
	winRate := float64(longGameWins) / float64(totalLongGames)

	if winRate < 0.6 {
		return nil
	}

	return &models.GamePattern{
		PatternID:     p.generatePatternID(userID, "late_game"),
		PatternType:   "victory",
		UserID:        userID,
		Description:   fmt.Sprintf("Strong performance in long games (%.1f%% win rate in 35+ min games)", winRate*100),
		Frequency:     frequency,
		Confidence:    p.calculateConfidence(totalLongGames),
		ImpactScore:   winRate * 100,
		FirstDetected: time.Now().AddDate(0, 0, -30),
		LastSeen:      time.Now(),
		Conditions:    []string{"Game duration >35min", "Late game scaling"},
		Suggestions:   []string{"Focus on scaling champions", "Prioritize farm over kills", "Play for late game team fights"},
	}
}

func (p *PatternDetectionService) detectVisionPattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// Analyze correlation between vision score and wins
	highVisionWins := 0
	totalHighVision := 0

	// Calculate average vision score
	totalVisionScore := 0.0
	for _, match := range matches {
		totalVisionScore += match["vision_score"].(float64)
	}
	avgVisionScore := totalVisionScore / float64(len(matches))

	for _, match := range matches {
		visionScore := match["vision_score"].(float64)
		if visionScore > avgVisionScore*1.2 { // 20% above average
			totalHighVision++
			if match["win"].(bool) {
				highVisionWins++
			}
		}
	}

	if totalHighVision < 5 {
		return nil
	}

	frequency := float64(totalHighVision) / float64(len(matches))
	winRate := float64(highVisionWins) / float64(totalHighVision)

	if winRate < 0.65 {
		return nil
	}

	return &models.GamePattern{
		PatternID:     p.generatePatternID(userID, "vision_control"),
		PatternType:   "victory",
		UserID:        userID,
		Description:   fmt.Sprintf("High win rate (%.1f%%) with strong vision control", winRate*100),
		Frequency:     frequency,
		Confidence:    p.calculateConfidence(totalHighVision),
		ImpactScore:   winRate * 100,
		FirstDetected: time.Now().AddDate(0, 0, -30),
		LastSeen:      time.Now(),
		Conditions:    []string{"High vision score", "Good ward placement"},
		Suggestions:   []string{"Continue prioritizing vision", "Ward key objectives", "Buy control wards regularly"},
	}
}

func (p *PatternDetectionService) detectObjectivePattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// This would require more detailed match data about objectives
	// For now, returning nil as we don't have objective data in our schema
	return nil
}

func (p *PatternDetectionService) detectChampionPatterns(matches []map[string]interface{}, userID int) []models.GamePattern {
	// Group matches by champion
	championStats := make(map[int]struct {
		wins    int
		total   int
		name    string
	})

	for _, match := range matches {
		championID := match["champion_id"].(int)
		championName := match["champion_name"].(string)
		
		stats := championStats[championID]
		stats.name = championName
		stats.total++
		if match["win"].(bool) {
			stats.wins++
		}
		championStats[championID] = stats
	}

	var patterns []models.GamePattern

	// Find champions with high win rates and sufficient games
	for championID, stats := range championStats {
		if stats.total < 5 { // Need at least 5 games
			continue
		}

		winRate := float64(stats.wins) / float64(stats.total)
		if winRate > 0.65 { // High win rate threshold
			pattern := models.GamePattern{
				PatternID:     p.generatePatternID(userID, fmt.Sprintf("champion_%d", championID)),
				PatternType:   "victory",
				UserID:        userID,
				Description:   fmt.Sprintf("High win rate (%.1f%%) with %s", winRate*100, stats.name),
				Frequency:     float64(stats.total) / float64(len(matches)),
				Confidence:    p.calculateConfidence(stats.total),
				ImpactScore:   winRate * 100,
				FirstDetected: time.Now().AddDate(0, 0, -30),
				LastSeen:      time.Now(),
				Conditions:    []string{fmt.Sprintf("Playing %s", stats.name)},
				Suggestions:   []string{fmt.Sprintf("Consider maining %s", stats.name), "Focus on this champion for ranked"},
			}
			patterns = append(patterns, pattern)
		}
	}

	return patterns
}

func (p *PatternDetectionService) detectFeedingPattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// Analyze games with high death counts and losses
	highDeathLosses := 0
	totalHighDeaths := 0

	for _, match := range matches {
		deaths := match["deaths"].(int)
		gameDuration := match["game_duration"].(int)
		deathsPerMin := float64(deaths) / (float64(gameDuration) / 60.0)

		if deathsPerMin > 0.4 { // More than 0.4 deaths per minute
			totalHighDeaths++
			if !match["win"].(bool) {
				highDeathLosses++
			}
		}
	}

	if totalHighDeaths < 5 {
		return nil
	}

	frequency := float64(totalHighDeaths) / float64(len(matches))
	lossRate := float64(highDeathLosses) / float64(totalHighDeaths)

	if lossRate < 0.7 {
		return nil
	}

	return &models.GamePattern{
		PatternID:     p.generatePatternID(userID, "feeding"),
		PatternType:   "defeat",
		UserID:        userID,
		Description:   fmt.Sprintf("High loss rate (%.1f%%) when dying frequently", lossRate*100),
		Frequency:     frequency,
		Confidence:    p.calculateConfidence(totalHighDeaths),
		ImpactScore:   lossRate * 100,
		FirstDetected: time.Now().AddDate(0, 0, -30),
		LastSeen:      time.Now(),
		Conditions:    []string{"High death rate", "Poor positioning"},
		Suggestions:   []string{"Focus on positioning", "Play more defensively", "Ward better to avoid ganks"},
	}
}

func (p *PatternDetectionService) detectLateGameThrowPattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// This would require more detailed timeline data to detect throws
	// For now, return nil as we need more game state information
	return nil
}

func (p *PatternDetectionService) detectPoorCSPattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// Analyze CS performance and its correlation with losses
	lowCSLosses := 0
	totalLowCS := 0

	// Calculate average CS per minute
	totalCS := 0.0
	csGames := 0
	for _, match := range matches {
		role := match["role"].(string)
		if role == "MIDDLE" || role == "TOP" || role == "BOTTOM" {
			totalCS += match["cs_per_min"].(float64)
			csGames++
		}
	}

	if csGames < 10 {
		return nil // Not enough data for CS analysis
	}

	avgCS := totalCS / float64(csGames)
	lowCSThreshold := avgCS * 0.7 // 30% below average

	for _, match := range matches {
		role := match["role"].(string)
		if role == "MIDDLE" || role == "TOP" || role == "BOTTOM" {
			csPerMin := match["cs_per_min"].(float64)
			if csPerMin < lowCSThreshold {
				totalLowCS++
				if !match["win"].(bool) {
					lowCSLosses++
				}
			}
		}
	}

	if totalLowCS < 5 {
		return nil
	}

	frequency := float64(totalLowCS) / float64(csGames)
	lossRate := float64(lowCSLosses) / float64(totalLowCS)

	if lossRate < 0.65 {
		return nil
	}

	return &models.GamePattern{
		PatternID:     p.generatePatternID(userID, "poor_cs"),
		PatternType:   "defeat",
		UserID:        userID,
		Description:   fmt.Sprintf("High loss rate (%.1f%%) with poor CS (<%0.1f CS/min)", lossRate*100, lowCSThreshold),
		Frequency:     frequency,
		Confidence:    p.calculateConfidence(totalLowCS),
		ImpactScore:   lossRate * 100,
		FirstDetected: time.Now().AddDate(0, 0, -30),
		LastSeen:      time.Now(),
		Conditions:    []string{"Poor farming", "Low CS per minute"},
		Suggestions:   []string{"Practice last-hitting", "Focus on farm over trades", "Use practice tool for CS drills"},
	}
}

func (p *PatternDetectionService) detectTiltPattern(matches []map[string]interface{}, userID int) *models.GamePattern {
	// Analyze losing streaks and performance degradation
	var streaks []int
	currentStreak := 0
	
	// Sort matches by game creation time (most recent first)
	sort.Slice(matches, func(i, j int) bool {
		return matches[i]["game_creation"].(int64) > matches[j]["game_creation"].(int64)
	})

	for _, match := range matches {
		if !match["win"].(bool) {
			currentStreak++
		} else {
			if currentStreak > 0 {
				streaks = append(streaks, currentStreak)
				currentStreak = 0
			}
		}
	}

	// Add final streak if it ends on a loss
	if currentStreak > 0 {
		streaks = append(streaks, currentStreak)
	}

	// Count significant losing streaks (3+ losses)
	significantStreaks := 0
	for _, streak := range streaks {
		if streak >= 3 {
			significantStreaks++
		}
	}

	if significantStreaks < 2 {
		return nil
	}

	frequency := float64(significantStreaks) / 10.0 // Approximate frequency over time
	
	return &models.GamePattern{
		PatternID:     p.generatePatternID(userID, "tilt"),
		PatternType:   "defeat",
		UserID:        userID,
		Description:   fmt.Sprintf("Tendency to go on losing streaks (%d significant streaks detected)", significantStreaks),
		Frequency:     math.Min(frequency, 1.0),
		Confidence:    0.7,
		ImpactScore:   float64(significantStreaks * 20), // Each streak costs ~20 points
		FirstDetected: time.Now().AddDate(0, 0, -30),
		LastSeen:      time.Now(),
		Conditions:    []string{"Losing streaks", "Emotional gameplay"},
		Suggestions:   []string{"Take breaks after losses", "Focus on mental health", "Review replays to identify mistakes"},
	}
}

// Timing analysis methods
func (p *PatternDetectionService) analyzeFirstBloodTiming(matches []map[string]interface{}) *models.TimingPattern {
	// This would require timeline data that we don't have in current schema
	return nil
}

func (p *PatternDetectionService) analyzeDragonTiming(matches []map[string]interface{}) *models.TimingPattern {
	// This would require objective timeline data
	return nil
}

func (p *PatternDetectionService) analyzeRecallTiming(matches []map[string]interface{}) *models.TimingPattern {
	// This would require detailed timeline data
	return nil
}

func (p *PatternDetectionService) analyzeTeamfightTiming(matches []map[string]interface{}) *models.TimingPattern {
	// This would require team fight timeline data
	return nil
}

// Performance anomaly detection methods
func (p *PatternDetectionService) getPerformanceMetricsTimeline(userID int, days int) ([]map[string]interface{}, error) {
	// This would return performance metrics grouped by time periods
	// For now, returning empty slice as we'd need to aggregate the data
	return []map[string]interface{}{}, nil
}

func (p *PatternDetectionService) detectKDAAnomalies(metrics []map[string]interface{}, userID int) []models.PerformanceAnomaly {
	return []models.PerformanceAnomaly{}
}

func (p *PatternDetectionService) detectCSAnomalies(metrics []map[string]interface{}, userID int) []models.PerformanceAnomaly {
	return []models.PerformanceAnomaly{}
}

func (p *PatternDetectionService) detectWinRateAnomalies(metrics []map[string]interface{}, userID int) []models.PerformanceAnomaly {
	return []models.PerformanceAnomaly{}
}

func (p *PatternDetectionService) detectDamageAnomalies(metrics []map[string]interface{}, userID int) []models.PerformanceAnomaly {
	return []models.PerformanceAnomaly{}
}

// Play style analysis methods
func (p *PatternDetectionService) calculateStyleMetrics(matches []map[string]interface{}) map[string]float64 {
	metrics := make(map[string]float64)

	var totalKills, totalDeaths, totalAssists, totalDamage, totalVision float64
	var totalGames float64

	for _, match := range matches {
		totalKills += float64(match["kills"].(int))
		totalDeaths += float64(match["deaths"].(int))
		totalAssists += float64(match["assists"].(int))
		totalDamage += match["damage_to_champions"].(float64)
		totalVision += match["vision_score"].(float64)
		totalGames++
	}

	metrics["avg_kills"] = totalKills / totalGames
	metrics["avg_deaths"] = totalDeaths / totalGames
	metrics["avg_assists"] = totalAssists / totalGames
	metrics["avg_damage"] = totalDamage / totalGames
	metrics["avg_vision"] = totalVision / totalGames
	
	// Calculate aggressiveness score
	metrics["aggressiveness"] = (metrics["avg_kills"] + metrics["avg_deaths"]) / 2.0
	
	// Calculate supportiveness score
	metrics["supportiveness"] = (metrics["avg_assists"] + metrics["avg_vision"]) / 2.0
	
	// Calculate safety score (inverse of deaths)
	metrics["safety"] = math.Max(0, 10 - metrics["avg_deaths"])

	return metrics
}

func (p *PatternDetectionService) determinePrimaryStyle(metrics map[string]float64) string {
	aggressiveness := metrics["aggressiveness"]
	supportiveness := metrics["supportiveness"]
	safety := metrics["safety"]

	if aggressiveness > 8 && metrics["avg_kills"] > metrics["avg_assists"] {
		return "aggressive"
	} else if safety > 7 && metrics["avg_deaths"] < 4 {
		return "defensive"
	} else if supportiveness > 8 && metrics["avg_assists"] > metrics["avg_kills"] {
		return "supportive"
	} else {
		return "balanced"
	}
}

func (p *PatternDetectionService) determineSecondaryStyle(metrics map[string]float64, primary string) string {
	switch primary {
	case "aggressive":
		if metrics["supportiveness"] > 6 {
			return "supportive"
		}
		return "balanced"
	case "defensive":
		if metrics["supportiveness"] > 6 {
			return "supportive"
		}
		return "balanced"
	case "supportive":
		if metrics["safety"] > 6 {
			return "defensive"
		}
		return "balanced"
	default:
		return "adaptive"
	}
}

func (p *PatternDetectionService) calculateStyleConfidence(metrics map[string]float64, primaryStyle string) float64 {
	// Calculate confidence based on how clearly defined the style is
	aggressiveness := metrics["aggressiveness"]
	supportiveness := metrics["supportiveness"]
	safety := metrics["safety"]

	switch primaryStyle {
	case "aggressive":
		return math.Min(aggressiveness / 10.0, 1.0)
	case "defensive":
		return math.Min(safety / 10.0, 1.0)
	case "supportive":
		return math.Min(supportiveness / 10.0, 1.0)
	default:
		return 0.6 // Moderate confidence for balanced style
	}
}

func (p *PatternDetectionService) calculateStyleConsistency(matches []map[string]interface{}, style string) float64 {
	// This would analyze game-by-game consistency of the identified style
	// For now, returning a reasonable default
	return 75.0
}

func (p *PatternDetectionService) calculateAdaptability(matches []map[string]interface{}) float64 {
	// Analyze how well the user adapts their style to different situations
	// This would require more detailed analysis of game contexts
	return 65.0
}

func (p *PatternDetectionService) getOptimalConditions(style string, metrics map[string]float64) []string {
	switch style {
	case "aggressive":
		return []string{"Early game champions", "Skirmish-heavy games", "Snowball compositions"}
	case "defensive":
		return []string{"Late game champions", "Team fight compositions", "Scaling strategies"}
	case "supportive":
		return []string{"Utility champions", "Vision-heavy games", "Team-oriented strategies"}
	default:
		return []string{"Flexible team compositions", "Adaptive strategies"}
	}
}

func (p *PatternDetectionService) getWeaknesses(style string, matches []map[string]interface{}) []string {
	switch style {
	case "aggressive":
		return []string{"Passive lane opponents", "Late game scaling teams", "Heavy CC compositions"}
	case "defensive":
		return []string{"Early game pressure", "Snowball compositions", "Aggressive junglers"}
	case "supportive":
		return []string{"Assassin compositions", "Solo carry requirements", "Low-utility teams"}
	default:
		return []string{"Highly specialized strategies"}
	}
}

// Utility methods
func (p *PatternDetectionService) generatePatternID(userID int, patternType string) string {
	return fmt.Sprintf("pattern_%d_%s_%d", userID, patternType, time.Now().Unix())
}

func (p *PatternDetectionService) calculateConfidence(sampleSize int) float64 {
	// Confidence based on sample size
	if sampleSize >= 20 {
		return 0.9
	} else if sampleSize >= 10 {
		return 0.75
	} else if sampleSize >= 5 {
		return 0.6
	}
	return 0.4
}
