package services

import (
	"database/sql"
	"fmt"
	"log"
	"math"
	"sort"
	"time"

	"lol-match-exporter/internal/models"
)

// PredictionService handles ML-based predictions and analysis
type PredictionService struct {
	db *sql.DB
}

// NewPredictionService creates a new prediction service
func NewPredictionService(db *sql.DB) *PredictionService {
	return &PredictionService{
		db: db,
	}
}

// PredictPerformance predicts future performance based on historical data
func (p *PredictionService) PredictPerformance(userID int, timeHorizon int, predictionType string) (*models.PerformancePrediction, error) {
	log.Printf("🔮 Predicting %s performance for user %d over %d days", predictionType, userID, timeHorizon)

	// Get historical performance data
	historicalData, err := p.getHistoricalPerformance(userID, 90) // Last 90 days
	if err != nil {
		return nil, fmt.Errorf("failed to get historical data: %w", err)
	}

	if len(historicalData) < 10 {
		return nil, fmt.Errorf("insufficient data for prediction (need at least 10 games)")
	}

	// Calculate current baseline
	currentBaseline := p.calculateCurrentBaseline(historicalData, predictionType)

	// Analyze performance factors
	factors := p.analyzePerformanceFactors(historicalData, userID)

	// Generate prediction scenarios
	scenarios := p.generatePredictionScenarios(historicalData, factors, timeHorizon)

	// Calculate main prediction (weighted average of scenarios)
	predictedValue := p.calculateWeightedPrediction(scenarios)

	// Calculate prediction confidence
	confidence := p.calculatePredictionConfidence(historicalData, factors)

	// Generate recommendations
	recommendations := p.generatePredictionRecommendations(factors, scenarios)

	prediction := &models.PerformancePrediction{
		UserID:          userID,
		PredictionID:    p.generatePredictionID(userID, predictionType),
		PredictionType:  predictionType,
		TimeHorizon:     timeHorizon,
		CurrentBaseline: currentBaseline,
		PredictedValue:  predictedValue,
		Confidence:      confidence,
		FactorsAnalyzed: factors,
		Scenarios:       scenarios,
		Recommendations: recommendations,
		CreatedAt:       time.Now(),
		ValidUntil:      time.Now().AddDate(0, 0, timeHorizon/2), // Valid for half the prediction horizon
	}

	log.Printf("✅ Generated performance prediction: baseline=%.2f, predicted=%.2f, confidence=%.2f", 
		currentBaseline, predictedValue, confidence)

	return prediction, nil
}

// RecommendOptimalChampions recommends champions based on team composition and meta
func (p *PredictionService) RecommendOptimalChampions(userID int, teamComposition []int, enemyComposition []int) ([]models.ChampionRecommendation, error) {
	log.Printf("🏆 Generating champion recommendations for user %d", userID)

	// Get user's champion performance history
	championStats, err := p.getUserChampionStats(userID)
	if err != nil {
		return nil, fmt.Errorf("failed to get champion stats: %w", err)
	}

	// Get current meta data
	metaData, err := p.getCurrentMetaData()
	if err != nil {
		log.Printf("⚠️ Failed to get meta data, using fallback: %v", err)
		metaData = make(map[string]float64) // Fallback to empty meta
	}

	// Analyze team composition synergies
	teamSynergies, err := p.analyzeTeamSynergies(teamComposition)
	if err != nil {
		log.Printf("⚠️ Failed to analyze team synergies: %v", err)
	}

	// Analyze enemy composition counters
	enemyCounters, err := p.analyzeEnemyCounters(enemyComposition)
	if err != nil {
		log.Printf("⚠️ Failed to analyze enemy counters: %v", err)
	}

	var recommendations []models.ChampionRecommendation

	// Evaluate each champion user has played
	for championID, stats := range championStats {
		if stats.GamesPlayed < 3 { // Skip champions with too few games
			continue
		}

		rec := p.evaluateChampionRecommendation(
			userID, championID, stats, 
			teamComposition, enemyComposition,
			metaData, teamSynergies, enemyCounters,
		)

		if rec.FitScore > 30 { // Only include decent recommendations
			recommendations = append(recommendations, rec)
		}
	}

	// Sort by fit score
	sort.Slice(recommendations, func(i, j int) bool {
		return recommendations[i].FitScore > recommendations[j].FitScore
	})

	// Limit to top 10 recommendations
	if len(recommendations) > 10 {
		recommendations = recommendations[:10]
	}

	log.Printf("✅ Generated %d champion recommendations", len(recommendations))
	return recommendations, nil
}

// PredictMatchOutcome predicts match outcome in real-time
func (p *PredictionService) PredictMatchOutcome(userID int, teamComp, enemyComp []int) (*models.MatchPrediction, error) {
	log.Printf("⚔️ Predicting match outcome for user %d", userID)

	// Analyze team strength
	teamStrength := p.analyzeTeamStrength(teamComp, userID)
	enemyStrength := p.analyzeTeamStrength(enemyComp, 0) // Don't have enemy user data

	// Calculate composition factors
	factors := p.calculateMatchFactors(teamComp, enemyComp, userID)

	// Predict win probability
	winProbability := p.calculateWinProbability(teamStrength, enemyStrength, factors)

	// Determine predicted outcome
	predictedOutcome := "loss"
	if winProbability > 0.5 {
		predictedOutcome = "win"
	}

	// Identify critical phases
	criticalPhases := p.identifyCriticalPhases(teamComp, enemyComp)

	// Generate strategic tips
	strategicTips := p.generateStrategicTips(teamComp, enemyComp, factors)

	prediction := &models.MatchPrediction{
		MatchID:          p.generateMatchID(),
		UserID:           userID,
		TeamComposition:  teamComp,
		EnemyComposition: enemyComp,
		PredictedOutcome: predictedOutcome,
		WinProbability:   winProbability,
		KeyFactors:       factors,
		CriticalPhases:   criticalPhases,
		StrategicTips:    strategicTips,
		UpdatedAt:        time.Now(),
	}

	log.Printf("✅ Match prediction: %s (%.1f%% confidence)", predictedOutcome, winProbability*100)
	return prediction, nil
}

// GenerateImprovementRoadmap creates a personalized improvement plan
func (p *PredictionService) GenerateImprovementRoadmap(userID int, targetLevel string) (*models.ImprovementRoadmap, error) {
	log.Printf("🛤️ Generating improvement roadmap for user %d to %s", userID, targetLevel)

	// Assess current level
	currentLevel, err := p.assessCurrentLevel(userID)
	if err != nil {
		return nil, fmt.Errorf("failed to assess current level: %w", err)
	}

	// Calculate estimated timeframe
	timeframe := p.calculateImprovementTimeframe(currentLevel, targetLevel, userID)

	// Generate milestones
	milestones := p.generateImprovementMilestones(currentLevel, targetLevel, timeframe)

	// Generate weekly goals
	weeklyGoals := p.generateWeeklyGoals(milestones, timeframe)

	// Determine tracking metrics
	trackingMetrics := p.selectTrackingMetrics(currentLevel, targetLevel)

	roadmap := &models.ImprovementRoadmap{
		UserID:             userID,
		RoadmapID:          p.generateRoadmapID(userID),
		CurrentLevel:       currentLevel,
		TargetLevel:        targetLevel,
		EstimatedTimeframe: timeframe,
		Milestones:         milestones,
		WeeklyGoals:        weeklyGoals,
		TrackingMetrics:    trackingMetrics,
		CreatedAt:          time.Now(),
		LastUpdated:        time.Now(),
		Progress:           0.0,
	}

	log.Printf("✅ Generated roadmap: %s -> %s (%d days, %d milestones)", 
		currentLevel, targetLevel, timeframe, len(milestones))

	return roadmap, nil
}

// DetectProgressionPlateau identifies when user hits a skill plateau
func (p *PredictionService) DetectProgressionPlateau(userID int) (*models.ProgressionPlateau, error) {
	log.Printf("📊 Detecting progression plateau for user %d", userID)

	// Get performance history
	history, err := p.getPerformanceHistory(userID, 60) // Last 60 days
	if err != nil {
		return nil, fmt.Errorf("failed to get performance history: %w", err)
	}

	// Analyze each metric for plateau patterns
	plateaus := p.analyzeMetricsForPlateau(history, userID)
	
	if len(plateaus) == 0 {
		return nil, nil // No plateau detected
	}

	// Find most significant plateau
	mostSignificant := plateaus[0]
	for _, plateau := range plateaus {
		if plateau.Duration > mostSignificant.Duration {
			mostSignificant = plateau
		}
	}

	log.Printf("✅ Detected plateau in %s (duration: %d days)", 
		mostSignificant.MetricAffected, mostSignificant.Duration)

	return &mostSignificant, nil
}

// Private helper methods

func (p *PredictionService) getHistoricalPerformance(userID int, days int) ([]map[string]interface{}, error) {
	query := `
		SELECT game_creation, win, kills, deaths, assists, 
			   cs_per_min, gold_per_min, damage_to_champions,
			   vision_score, champion_id, champion_name, role,
			   game_duration
		FROM matches 
		WHERE user_id = ? AND game_creation >= ?
		ORDER BY game_creation DESC
	`

	startTime := time.Now().AddDate(0, 0, -days).Unix() * 1000
	rows, err := p.db.Query(query, userID, startTime)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var matches []map[string]interface{}
	for rows.Next() {
		match := make(map[string]interface{})
		var gameCreation int64
		var win, kills, deaths, assists int
		var csPerMin, goldPerMin, damageToChampions, visionScore float64
		var championID int
		var championName, role string
		var gameDuration int

		err := rows.Scan(
			&gameCreation, &win, &kills, &deaths, &assists,
			&csPerMin, &goldPerMin, &damageToChampions,
			&visionScore, &championID, &championName, &role,
			&gameDuration,
		)
		if err != nil {
			continue
		}

		match["game_creation"] = gameCreation
		match["win"] = win
		match["kills"] = kills
		match["deaths"] = deaths
		match["assists"] = assists
		match["cs_per_min"] = csPerMin
		match["gold_per_min"] = goldPerMin
		match["damage_to_champions"] = damageToChampions
		match["vision_score"] = visionScore
		match["champion_id"] = championID
		match["champion_name"] = championName
		match["role"] = role
		match["game_duration"] = gameDuration

		matches = append(matches, match)
	}

	return matches, nil
}

func (p *PredictionService) calculateCurrentBaseline(data []map[string]interface{}, predictionType string) float64 {
	if len(data) == 0 {
		return 0
	}

	recentGames := data
	if len(data) > 20 {
		recentGames = data[:20] // Last 20 games
	}

	switch predictionType {
	case "winrate":
		wins := 0
		for _, match := range recentGames {
			if match["win"].(int) == 1 {
				wins++
			}
		}
		return float64(wins) / float64(len(recentGames)) * 100

	case "kda":
		var totalKDA float64
		for _, match := range recentGames {
			kills := float64(match["kills"].(int))
			deaths := float64(match["deaths"].(int))
			assists := float64(match["assists"].(int))
			
			kda := kills + assists
			if deaths > 0 {
				kda = (kills + assists) / deaths
			}
			totalKDA += kda
		}
		return totalKDA / float64(len(recentGames))

	case "cs_per_min":
		var totalCS float64
		for _, match := range recentGames {
			totalCS += match["cs_per_min"].(float64)
		}
		return totalCS / float64(len(recentGames))

	default:
		return 50 // Default baseline
	}
}

func (p *PredictionService) analyzePerformanceFactors(data []map[string]interface{}, userID int) []models.PredictionFactor {
	var factors []models.PredictionFactor

	// Analyze recent trend
	trendImpact := p.calculateTrendImpact(data)
	factors = append(factors, models.PredictionFactor{
		FactorName:   "Recent Trend",
		Impact:       trendImpact,
		CurrentValue: p.getRecentTrendValue(data),
		Trend:        p.getTrendDirection(trendImpact),
		Description:  "Your performance trend over recent games",
	})

	// Analyze consistency
	consistencyImpact := p.calculateConsistencyImpact(data)
	factors = append(factors, models.PredictionFactor{
		FactorName:   "Performance Consistency",
		Impact:       consistencyImpact,
		CurrentValue: p.getConsistencyValue(data),
		Trend:        p.getTrendDirection(consistencyImpact),
		Description:  "How consistent your performance has been",
	})

	// Analyze champion pool depth
	poolImpact := p.calculateChampionPoolImpact(data)
	factors = append(factors, models.PredictionFactor{
		FactorName:   "Champion Pool Depth",
		Impact:       poolImpact,
		CurrentValue: p.getChampionPoolValue(data),
		Trend:        "stable",
		Description:  "Diversity and mastery of your champion pool",
	})

	return factors
}

func (p *PredictionService) generatePredictionScenarios(data []map[string]interface{}, factors []models.PredictionFactor, timeHorizon int) []models.PredictionScenario {
	currentBaseline := p.calculateCurrentBaseline(data, "winrate")
	
	scenarios := []models.PredictionScenario{
		{
			ScenarioName:     "Optimistic",
			Probability:      0.25,
			PredictedOutcome: currentBaseline + 8.0, // +8% winrate improvement
			RequiredChanges:  []string{"Maintain current performance", "Focus on identified strengths"},
			Description:      "Best case scenario with continued improvement",
		},
		{
			ScenarioName:     "Realistic",
			Probability:      0.50,
			PredictedOutcome: currentBaseline + 3.0, // +3% winrate improvement
			RequiredChanges:  []string{"Consistent practice", "Address key weaknesses"},
			Description:      "Most likely scenario with steady improvement",
		},
		{
			ScenarioName:     "Conservative",
			Probability:      0.25,
			PredictedOutcome: currentBaseline - 1.0, // -1% winrate (slight decline)
			RequiredChanges:  []string{"Refocus on fundamentals", "Prevent tilt and bad habits"},
			Description:      "Cautious scenario with minimal change",
		},
	}

	// Adjust based on factors
	for _, factor := range factors {
		if factor.Impact > 0 {
			// Positive factor - boost optimistic scenario
			scenarios[0].PredictedOutcome += factor.Impact * 0.1
			scenarios[1].PredictedOutcome += factor.Impact * 0.05
		} else {
			// Negative factor - lower expectations
			scenarios[2].PredictedOutcome += factor.Impact * 0.1
			scenarios[1].PredictedOutcome += factor.Impact * 0.05
		}
	}

	return scenarios
}

func (p *PredictionService) calculateWeightedPrediction(scenarios []models.PredictionScenario) float64 {
	var weightedSum, totalWeight float64
	
	for _, scenario := range scenarios {
		weightedSum += scenario.PredictedOutcome * scenario.Probability
		totalWeight += scenario.Probability
	}
	
	if totalWeight == 0 {
		return 50 // Fallback
	}
	
	return weightedSum / totalWeight
}

func (p *PredictionService) calculatePredictionConfidence(data []map[string]interface{}, factors []models.PredictionFactor) float64 {
	// Base confidence from data quantity
	dataConfidence := math.Min(float64(len(data))/50.0, 1.0)
	
	// Factor confidence from consistency
	factorConfidence := 0.5
	for _, factor := range factors {
		if factor.FactorName == "Performance Consistency" {
			factorConfidence = factor.CurrentValue / 100.0
			break
		}
	}
	
	// Combine confidences
	return (dataConfidence*0.6 + factorConfidence*0.4) * 0.85 // Cap at 85%
}

func (p *PredictionService) generatePredictionRecommendations(factors []models.PredictionFactor, scenarios []models.PredictionScenario) []string {
	var recommendations []string
	
	// Analyze factors for recommendations
	for _, factor := range factors {
		if factor.Impact < -10 { // Significant negative impact
			switch factor.FactorName {
			case "Recent Trend":
				recommendations = append(recommendations, "Focus on breaking negative performance trends")
			case "Performance Consistency":
				recommendations = append(recommendations, "Work on maintaining consistent performance across games")
			case "Champion Pool Depth":
				recommendations = append(recommendations, "Expand and deepen your champion mastery")
			}
		}
	}
	
	// Add scenario-based recommendations
	optimisticScenario := scenarios[0]
	if optimisticScenario.PredictedOutcome > 60 {
		recommendations = append(recommendations, "You're on track for significant improvement - maintain current approach")
	}
	
	if len(recommendations) == 0 {
		recommendations = append(recommendations, "Continue focusing on fundamentals and consistent practice")
	}
	
	return recommendations
}

// Additional helper methods for calculations
func (p *PredictionService) calculateTrendImpact(data []map[string]interface{}) float64 {
	if len(data) < 10 {
		return 0
	}
	
	recentWins := 0
	olderWins := 0
	
	// Compare recent 10 games vs previous 10 games
	for i := 0; i < 10 && i < len(data); i++ {
		if data[i]["win"].(int) == 1 {
			recentWins++
		}
	}
	
	for i := 10; i < 20 && i < len(data); i++ {
		if data[i]["win"].(int) == 1 {
			olderWins++
		}
	}
	
	recentWinRate := float64(recentWins) / 10.0
	olderWinRate := float64(olderWins) / 10.0
	
	return (recentWinRate - olderWinRate) * 100 // Convert to percentage points
}

func (p *PredictionService) getRecentTrendValue(data []map[string]interface{}) float64 {
	if len(data) < 10 {
		return 50
	}
	
	wins := 0
	for i := 0; i < 10; i++ {
		if data[i]["win"].(int) == 1 {
			wins++
		}
	}
	
	return float64(wins) * 10 // Convert to percentage
}

func (p *PredictionService) getTrendDirection(impact float64) string {
	if impact > 5 {
		return "improving"
	} else if impact < -5 {
		return "declining"
	}
	return "stable"
}

func (p *PredictionService) calculateConsistencyImpact(data []map[string]interface{}) float64 {
	if len(data) < 5 {
		return 0
	}
	
	// Calculate KDA variance as consistency metric
	var kdas []float64
	for _, match := range data {
		kills := float64(match["kills"].(int))
		deaths := float64(match["deaths"].(int))
		assists := float64(match["assists"].(int))
		
		kda := kills + assists
		if deaths > 0 {
			kda = (kills + assists) / deaths
		}
		kdas = append(kdas, kda)
	}
	
	// Calculate coefficient of variation (lower = more consistent)
	mean, variance := p.calculateMeanAndVariance(kdas)
	if mean == 0 {
		return 0
	}
	
	cv := math.Sqrt(variance) / mean
	
	// Convert to impact score (lower CV = positive impact)
	return math.Max(-50, 30-cv*20)
}

func (p *PredictionService) getConsistencyValue(data []map[string]interface{}) float64 {
	if len(data) < 5 {
		return 50
	}
	
	// Use win rate consistency as simple metric
	wins := 0
	for _, match := range data {
		if match["win"].(int) == 1 {
			wins++
		}
	}
	
	winRate := float64(wins) / float64(len(data))
	
	// Consistency is inversely related to how far from 50% we are
	deviation := math.Abs(winRate - 0.5)
	consistency := (0.5 - deviation) * 2 * 100
	
	return math.Max(0, consistency)
}

func (p *PredictionService) calculateChampionPoolImpact(data []map[string]interface{}) float64 {
	champions := make(map[int]int)
	
	for _, match := range data {
		championID := match["champion_id"].(int)
		champions[championID]++
	}
	
	poolSize := len(champions)
	
	// Impact based on pool diversity
	if poolSize < 3 {
		return -20 // Too narrow
	} else if poolSize > 8 {
		return -10 // Too wide, lack of mastery
	}
	
	return 10 // Good pool size
}

func (p *PredictionService) getChampionPoolValue(data []map[string]interface{}) float64 {
	champions := make(map[int]int)
	
	for _, match := range data {
		championID := match["champion_id"].(int)
		champions[championID]++
	}
	
	return float64(len(champions))
}

func (p *PredictionService) calculateMeanAndVariance(values []float64) (float64, float64) {
	if len(values) == 0 {
		return 0, 0
	}
	
	// Calculate mean
	sum := 0.0
	for _, v := range values {
		sum += v
	}
	mean := sum / float64(len(values))
	
	// Calculate variance
	sumSquaredDiff := 0.0
	for _, v := range values {
		diff := v - mean
		sumSquaredDiff += diff * diff
	}
	variance := sumSquaredDiff / float64(len(values))
	
	return mean, variance
}

// Utility methods for ID generation
func (p *PredictionService) generatePredictionID(userID int, predictionType string) string {
	return fmt.Sprintf("pred_%d_%s_%d", userID, predictionType, time.Now().Unix())
}

func (p *PredictionService) generateMatchID() string {
	return fmt.Sprintf("match_%d", time.Now().UnixNano())
}

func (p *PredictionService) generateRoadmapID(userID int) string {
	return fmt.Sprintf("roadmap_%d_%d", userID, time.Now().Unix())
}

// Stub methods for features to be implemented
func (p *PredictionService) getUserChampionStats(userID int) (map[int]models.ChampionStats, error) {
	return make(map[int]models.ChampionStats), nil
}

func (p *PredictionService) getCurrentMetaData() (map[string]float64, error) {
	return make(map[string]float64), nil
}

func (p *PredictionService) analyzeTeamSynergies(teamComp []int) (map[string]float64, error) {
	return make(map[string]float64), nil
}

func (p *PredictionService) analyzeEnemyCounters(enemyComp []int) (map[string]float64, error) {
	return make(map[string]float64), nil
}

func (p *PredictionService) evaluateChampionRecommendation(userID, championID int, stats models.ChampionStats, teamComp, enemyComp []int, metaData, teamSynergies, enemyCounters map[string]float64) models.ChampionRecommendation {
	return models.ChampionRecommendation{
		UserID:           userID,
		ChampionID:       championID,
		FitScore:         50,
		ExpectedWinRate:  stats.WinRate,
		Confidence:       0.5,
	}
}

func (p *PredictionService) analyzeTeamStrength(teamComp []int, userID int) float64 {
	return 50.0 // Default neutral strength
}

func (p *PredictionService) calculateMatchFactors(teamComp, enemyComp []int, userID int) []models.PredictionFactor {
	return []models.PredictionFactor{}
}

func (p *PredictionService) calculateWinProbability(teamStrength, enemyStrength float64, factors []models.PredictionFactor) float64 {
	base := teamStrength / (teamStrength + enemyStrength)
	
	// Apply factor adjustments
	for _, factor := range factors {
		base += factor.Impact / 1000.0 // Small adjustments
	}
	
	return math.Max(0.1, math.Min(0.9, base)) // Clamp between 10% and 90%
}

func (p *PredictionService) identifyCriticalPhases(teamComp, enemyComp []int) []string {
	return []string{"Early Game", "Team Fight Phase", "Late Game"}
}

func (p *PredictionService) generateStrategicTips(teamComp, enemyComp []int, factors []models.PredictionFactor) []string {
	return []string{
		"Focus on objective control",
		"Maintain vision around key areas",
		"Play to your team's win condition",
	}
}

func (p *PredictionService) assessCurrentLevel(userID int) (string, error) {
	return "Gold", nil // Placeholder
}

func (p *PredictionService) calculateImprovementTimeframe(current, target string, userID int) int {
	return 30 // Default 30 days
}

func (p *PredictionService) generateImprovementMilestones(current, target string, timeframe int) []models.ImprovementMilestone {
	return []models.ImprovementMilestone{}
}

func (p *PredictionService) generateWeeklyGoals(milestones []models.ImprovementMilestone, timeframe int) []models.WeeklyGoal {
	return []models.WeeklyGoal{}
}

func (p *PredictionService) selectTrackingMetrics(current, target string) []string {
	return []string{"winrate", "kda", "cs_per_min", "vision_score"}
}

func (p *PredictionService) getPerformanceHistory(userID, days int) ([]map[string]float64, error) {
	return []map[string]float64{}, nil
}

func (p *PredictionService) analyzeMetricsForPlateau(history []map[string]float64, userID int) []models.ProgressionPlateau {
	return []models.ProgressionPlateau{}
}
