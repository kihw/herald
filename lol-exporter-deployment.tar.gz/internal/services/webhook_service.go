package services

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// WebhookService gère les intégrations externes via webhooks
type WebhookService struct {
	client     *http.Client
	retryCount int
}

// NewWebhookService crée une nouvelle instance du service webhook
func NewWebhookService() *WebhookService {
	return &WebhookService{
		client: &http.Client{
			Timeout: 30 * time.Second,
		},
		retryCount: 3,
	}
}

// DiscordWebhookPayload représente un payload Discord
type DiscordWebhookPayload struct {
	Content string                `json:"content,omitempty"`
	Embeds  []DiscordEmbed        `json:"embeds,omitempty"`
	TTS     bool                  `json:"tts,omitempty"`
}

// DiscordEmbed représente un embed Discord
type DiscordEmbed struct {
	Title       string              `json:"title,omitempty"`
	Description string              `json:"description,omitempty"`
	URL         string              `json:"url,omitempty"`
	Color       int                 `json:"color,omitempty"`
	Timestamp   string              `json:"timestamp,omitempty"`
	Footer      *DiscordEmbedFooter `json:"footer,omitempty"`
	Thumbnail   *DiscordEmbedImage  `json:"thumbnail,omitempty"`
	Image       *DiscordEmbedImage  `json:"image,omitempty"`
	Author      *DiscordEmbedAuthor `json:"author,omitempty"`
	Fields      []DiscordEmbedField `json:"fields,omitempty"`
}

// DiscordEmbedFooter représente le footer d'un embed Discord
type DiscordEmbedFooter struct {
	Text    string `json:"text"`
	IconURL string `json:"icon_url,omitempty"`
}

// DiscordEmbedImage représente une image d'embed Discord
type DiscordEmbedImage struct {
	URL      string `json:"url"`
	ProxyURL string `json:"proxy_url,omitempty"`
	Height   int    `json:"height,omitempty"`
	Width    int    `json:"width,omitempty"`
}

// DiscordEmbedAuthor représente l'auteur d'un embed Discord
type DiscordEmbedAuthor struct {
	Name    string `json:"name"`
	URL     string `json:"url,omitempty"`
	IconURL string `json:"icon_url,omitempty"`
}

// DiscordEmbedField représente un champ d'embed Discord
type DiscordEmbedField struct {
	Name   string `json:"name"`
	Value  string `json:"value"`
	Inline bool   `json:"inline,omitempty"`
}

// SlackWebhookPayload représente un payload Slack
type SlackWebhookPayload struct {
	Text        string             `json:"text,omitempty"`
	Username    string             `json:"username,omitempty"`
	IconEmoji   string             `json:"icon_emoji,omitempty"`
	IconURL     string             `json:"icon_url,omitempty"`
	Channel     string             `json:"channel,omitempty"`
	Attachments []SlackAttachment  `json:"attachments,omitempty"`
	Blocks      []SlackBlock       `json:"blocks,omitempty"`
}

// SlackAttachment représente un attachment Slack
type SlackAttachment struct {
	Color     string       `json:"color,omitempty"`
	Pretext   string       `json:"pretext,omitempty"`
	Title     string       `json:"title,omitempty"`
	TitleLink string       `json:"title_link,omitempty"`
	Text      string       `json:"text,omitempty"`
	Fields    []SlackField `json:"fields,omitempty"`
	Footer    string       `json:"footer,omitempty"`
	Timestamp int64        `json:"ts,omitempty"`
}

// SlackField représente un champ Slack
type SlackField struct {
	Title string `json:"title"`
	Value string `json:"value"`
	Short bool   `json:"short"`
}

// SlackBlock représente un block Slack (structure simplifiée)
type SlackBlock struct {
	Type string      `json:"type"`
	Text interface{} `json:"text,omitempty"`
}

// StatsUpdate représente une mise à jour de statistiques
type StatsUpdate struct {
	PlayerName      string    `json:"player_name"`
	RiotID          string    `json:"riot_id"`
	RiotTag         string    `json:"riot_tag"`
	Region          string    `json:"region"`
	TotalMatches    int       `json:"total_matches"`
	RecentMatches   int       `json:"recent_matches"`
	WinRate         float64   `json:"win_rate"`
	RecentWinRate   float64   `json:"recent_win_rate"`
	Rank            string    `json:"rank"`
	LP              int       `json:"lp"`
	MainChampion    string    `json:"main_champion"`
	LastMatchResult string    `json:"last_match_result"`
	Timestamp       time.Time `json:"timestamp"`
}

// SendDiscordWebhook envoie des statistiques via Discord webhook
func (ws *WebhookService) SendDiscordWebhook(webhookURL string, stats StatsUpdate) error {
	embed := DiscordEmbed{
		Title:       "📊 LoL Match Statistics Update",
		Description: fmt.Sprintf("Statistics update for **%s#%s**", stats.RiotID, stats.RiotTag),
		Color:       ws.getColorFromWinRate(stats.WinRate),
		Timestamp:   stats.Timestamp.Format(time.RFC3339),
		Thumbnail: &DiscordEmbedImage{
			URL: "https://ddragon.leagueoflegends.com/cdn/13.18.1/img/champion/" + stats.MainChampion + ".png",
		},
		Footer: &DiscordEmbedFooter{
			Text:    "LoL Match Exporter",
			IconURL: "https://www.riotgames.com/darkroom/1440/d0807e131a84d0db2c7fb53ad9ebfe0e:8d76242c8a25ad4ba6a2b8dd3e10f4cb/lol-logo.png",
		},
		Fields: []DiscordEmbedField{
			{
				Name:   "🏆 Rank",
				Value:  fmt.Sprintf("%s (%d LP)", stats.Rank, stats.LP),
				Inline: true,
			},
			{
				Name:   "📈 Win Rate",
				Value:  fmt.Sprintf("%.1f%% (%d/%d)", stats.WinRate, int(float64(stats.TotalMatches)*stats.WinRate/100), stats.TotalMatches),
				Inline: true,
			},
			{
				Name:   "🎮 Recent Performance",
				Value:  fmt.Sprintf("%.1f%% in last %d games", stats.RecentWinRate, stats.RecentMatches),
				Inline: true,
			},
			{
				Name:   "⭐ Main Champion",
				Value:  stats.MainChampion,
				Inline: true,
			},
			{
				Name:   "🆕 Last Match",
				Value:  stats.LastMatchResult,
				Inline: true,
			},
			{
				Name:   "🌍 Region",
				Value:  strings.ToUpper(stats.Region),
				Inline: true,
			},
		},
	}

	payload := DiscordWebhookPayload{
		Embeds: []DiscordEmbed{embed},
	}

	return ws.sendWebhook(webhookURL, payload)
}

// SendSlackWebhook envoie des statistiques via Slack webhook
func (ws *WebhookService) SendSlackWebhook(webhookURL string, stats StatsUpdate) error {
	attachment := SlackAttachment{
		Color:     ws.getSlackColorFromWinRate(stats.WinRate),
		Title:     "📊 LoL Match Statistics Update",
		Text:      fmt.Sprintf("Statistics update for *%s#%s*", stats.RiotID, stats.RiotTag),
		Timestamp: stats.Timestamp.Unix(),
		Footer:    "LoL Match Exporter",
		Fields: []SlackField{
			{
				Title: "🏆 Rank",
				Value: fmt.Sprintf("%s (%d LP)", stats.Rank, stats.LP),
				Short: true,
			},
			{
				Title: "📈 Win Rate",
				Value: fmt.Sprintf("%.1f%% (%d/%d)", stats.WinRate, int(float64(stats.TotalMatches)*stats.WinRate/100), stats.TotalMatches),
				Short: true,
			},
			{
				Title: "🎮 Recent Performance",
				Value: fmt.Sprintf("%.1f%% in last %d games", stats.RecentWinRate, stats.RecentMatches),
				Short: true,
			},
			{
				Title: "⭐ Main Champion",
				Value: stats.MainChampion,
				Short: true,
			},
			{
				Title: "🆕 Last Match",
				Value: stats.LastMatchResult,
				Short: true,
			},
			{
				Title: "🌍 Region",
				Value: strings.ToUpper(stats.Region),
				Short: true,
			},
		},
	}

	payload := SlackWebhookPayload{
		Attachments: []SlackAttachment{attachment},
		Username:    "LoL Match Exporter",
		IconEmoji:   ":video_game:",
	}

	return ws.sendWebhook(webhookURL, payload)
}

// SendGenericWebhook envoie des données JSON génériques
func (ws *WebhookService) SendGenericWebhook(webhookURL string, data interface{}) error {
	return ws.sendWebhook(webhookURL, data)
}

// SendMatchNotification envoie une notification de match
func (ws *WebhookService) SendMatchNotification(webhookURL string, matchData MatchData, isDiscord bool) error {
	if isDiscord {
		return ws.sendDiscordMatchNotification(webhookURL, matchData)
	}
	return ws.sendSlackMatchNotification(webhookURL, matchData)
}

// sendDiscordMatchNotification envoie une notification Discord pour un match
func (ws *WebhookService) sendDiscordMatchNotification(webhookURL string, match MatchData) error {
	resultEmoji := "❌"
	resultColor := 0xFF0000 // Rouge
	if match.Win {
		resultEmoji = "✅"
		resultColor = 0x00FF00 // Vert
	}

	embed := DiscordEmbed{
		Title:       fmt.Sprintf("%s Match Result", resultEmoji),
		Description: fmt.Sprintf("**%s** as **%s**", match.GameMode, match.ChampionName),
		Color:       resultColor,
		Timestamp:   match.GameCreation.Format(time.RFC3339),
		Thumbnail: &DiscordEmbedImage{
			URL: fmt.Sprintf("https://ddragon.leagueoflegends.com/cdn/13.18.1/img/champion/%s.png", match.ChampionName),
		},
		Fields: []DiscordEmbedField{
			{
				Name:   "📊 KDA",
				Value:  fmt.Sprintf("%d/%d/%d (%.2f)", match.Kills, match.Deaths, match.Assists, match.KDA),
				Inline: true,
			},
			{
				Name:   "⏱️ Duration",
				Value:  fmt.Sprintf("%d:%02d", match.GameDuration/60, match.GameDuration%60),
				Inline: true,
			},
			{
				Name:   "🗡️ Role",
				Value:  fmt.Sprintf("%s (%s)", match.Role, match.Lane),
				Inline: true,
			},
			{
				Name:   "💰 Gold",
				Value:  fmt.Sprintf("%s", formatNumber(match.Gold)),
				Inline: true,
			},
			{
				Name:   "⚔️ Damage",
				Value:  fmt.Sprintf("%s", formatNumber(match.Damage)),
				Inline: true,
			},
			{
				Name:   "👁️ Vision",
				Value:  fmt.Sprintf("%d", match.Vision),
				Inline: true,
			},
		},
	}

	payload := DiscordWebhookPayload{
		Embeds: []DiscordEmbed{embed},
	}

	return ws.sendWebhook(webhookURL, payload)
}

// sendSlackMatchNotification envoie une notification Slack pour un match
func (ws *WebhookService) sendSlackMatchNotification(webhookURL string, match MatchData) error {
	resultEmoji := ":x:"
	color := "danger"
	if match.Win {
		resultEmoji = ":white_check_mark:"
		color = "good"
	}

	attachment := SlackAttachment{
		Color:     color,
		Title:     fmt.Sprintf("%s Match Result", resultEmoji),
		Text:      fmt.Sprintf("*%s* as *%s*", match.GameMode, match.ChampionName),
		Timestamp: match.GameCreation.Unix(),
		Fields: []SlackField{
			{
				Title: "📊 KDA",
				Value: fmt.Sprintf("%d/%d/%d (%.2f)", match.Kills, match.Deaths, match.Assists, match.KDA),
				Short: true,
			},
			{
				Title: "⏱️ Duration",
				Value: fmt.Sprintf("%d:%02d", match.GameDuration/60, match.GameDuration%60),
				Short: true,
			},
			{
				Title: "🗡️ Role",
				Value: fmt.Sprintf("%s (%s)", match.Role, match.Lane),
				Short: true,
			},
			{
				Title: "💰 Gold",
				Value: formatNumber(match.Gold),
				Short: true,
			},
			{
				Title: "⚔️ Damage",
				Value: formatNumber(match.Damage),
				Short: true,
			},
			{
				Title: "👁️ Vision",
				Value: fmt.Sprintf("%d", match.Vision),
				Short: true,
			},
		},
	}

	payload := SlackWebhookPayload{
		Attachments: []SlackAttachment{attachment},
		Username:    "LoL Match Exporter",
		IconEmoji:   ":video_game:",
	}

	return ws.sendWebhook(webhookURL, payload)
}

// sendWebhook envoie un webhook HTTP
func (ws *WebhookService) sendWebhook(url string, payload interface{}) error {
	jsonData, err := json.Marshal(payload)
	if err != nil {
		return fmt.Errorf("failed to marshal webhook payload: %w", err)
	}

	var lastErr error
	for attempt := 0; attempt < ws.retryCount; attempt++ {
		if attempt > 0 {
			time.Sleep(time.Duration(attempt) * time.Second)
		}

		req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
		if err != nil {
			lastErr = fmt.Errorf("failed to create request: %w", err)
			continue
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("User-Agent", "LoL-Match-Exporter/2.0")

		resp, err := ws.client.Do(req)
		if err != nil {
			lastErr = fmt.Errorf("failed to send webhook (attempt %d): %w", attempt+1, err)
			continue
		}

		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()

		if resp.StatusCode >= 200 && resp.StatusCode < 300 {
			return nil // Succès
		}

		lastErr = fmt.Errorf("webhook failed with status %d (attempt %d): %s", 
			resp.StatusCode, attempt+1, string(body))
		
		// Ne pas retenter les erreurs 4xx
		if resp.StatusCode >= 400 && resp.StatusCode < 500 {
			break
		}
	}

	return lastErr
}

// getColorFromWinRate retourne une couleur Discord basée sur le winrate
func (ws *WebhookService) getColorFromWinRate(winRate float64) int {
	if winRate >= 70 {
		return 0x00FF00 // Vert brillant
	} else if winRate >= 60 {
		return 0x90EE90 // Vert clair
	} else if winRate >= 50 {
		return 0xFFFF00 // Jaune
	} else if winRate >= 40 {
		return 0xFF8C00 // Orange
	} else {
		return 0xFF0000 // Rouge
	}
}

// getSlackColorFromWinRate retourne une couleur Slack basée sur le winrate
func (ws *WebhookService) getSlackColorFromWinRate(winRate float64) string {
	if winRate >= 60 {
		return "good"
	} else if winRate >= 45 {
		return "warning"
	} else {
		return "danger"
	}
}

// formatNumber formate un nombre avec des séparateurs
func formatNumber(n int) string {
	if n < 1000 {
		return fmt.Sprintf("%d", n)
	} else if n < 1000000 {
		return fmt.Sprintf("%.1fK", float64(n)/1000)
	} else {
		return fmt.Sprintf("%.1fM", float64(n)/1000000)
	}
}

// TestWebhook teste un webhook avec un message simple
func (ws *WebhookService) TestWebhook(webhookURL string, isDiscord bool) error {
	if isDiscord {
		payload := DiscordWebhookPayload{
			Content: "🧪 Test message from LoL Match Exporter",
			Embeds: []DiscordEmbed{
				{
					Title:       "✅ Webhook Test",
					Description: "Your Discord webhook is working correctly!",
					Color:       0x00FF00,
					Timestamp:   time.Now().Format(time.RFC3339),
					Footer: &DiscordEmbedFooter{
						Text: "LoL Match Exporter",
					},
				},
			},
		}
		return ws.sendWebhook(webhookURL, payload)
	} else {
		payload := SlackWebhookPayload{
			Text:      "🧪 Test message from LoL Match Exporter",
			Username:  "LoL Match Exporter",
			IconEmoji: ":video_game:",
			Attachments: []SlackAttachment{
				{
					Color: "good",
					Title: "✅ Webhook Test",
					Text:  "Your Slack webhook is working correctly!",
				},
			},
		}
		return ws.sendWebhook(webhookURL, payload)
	}
}

// ValidateWebhookURL valide une URL de webhook
func (ws *WebhookService) ValidateWebhookURL(url string) error {
	if url == "" {
		return fmt.Errorf("webhook URL cannot be empty")
	}

	if !strings.HasPrefix(url, "http://") && !strings.HasPrefix(url, "https://") {
		return fmt.Errorf("webhook URL must start with http:// or https://")
	}

	// Validation spécifique Discord
	if strings.Contains(url, "discord.com/api/webhooks/") {
		parts := strings.Split(url, "/")
		if len(parts) < 7 {
			return fmt.Errorf("invalid Discord webhook URL format")
		}
	}

	// Validation spécifique Slack
	if strings.Contains(url, "hooks.slack.com") {
		if !strings.Contains(url, "/services/") {
			return fmt.Errorf("invalid Slack webhook URL format")
		}
	}

	return nil
}

// GetWebhookInfo retourne des informations sur un webhook
func (ws *WebhookService) GetWebhookInfo(url string) map[string]string {
	info := map[string]string{
		"url":  url,
		"type": "generic",
	}

	if strings.Contains(url, "discord.com") {
		info["type"] = "discord"
		info["platform"] = "Discord"
	} else if strings.Contains(url, "slack.com") {
		info["type"] = "slack"
		info["platform"] = "Slack"
	}

	return info
}
