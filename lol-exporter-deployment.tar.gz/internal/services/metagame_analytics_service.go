// Package services provides business logic services
package services

import (
	"database/sql"
	"fmt"
	"log"
	"math"
	"time"

	"lol-match-exporter/internal/models"
)

// MetaGameAnalyticsService handles advanced meta-game analysis
type MetaGameAnalyticsService struct {
	db *sql.DB
}

// NewMetaGameAnalyticsService creates a new meta-game analytics service
func NewMetaGameAnalyticsService(db *sql.DB) *MetaGameAnalyticsService {
	return &MetaGameAnalyticsService{
		db: db,
	}
}

// AnalyzePatchTrends analyzes champion and item trends by game patch
func (m *MetaGameAnalyticsService) AnalyzePatchTrends(patch string, region string) (*models.PatchTrends, error) {
	log.Printf("🔍 Analyzing patch trends for %s in region %s", patch, region)
	
	// Get champion trends for the patch
	championTrends, err := m.getChampionTrendsByPatch(patch, region)
	if err != nil {
		return nil, fmt.Errorf("failed to get champion trends: %w", err)
	}

	// Get item trends for the patch
	itemTrends, err := m.getItemTrendsByPatch(patch, region)
	if err != nil {
		return nil, fmt.Errorf("failed to get item trends: %w", err)
	}

	// Get ban trends
	banTrends, err := m.getBanTrendsByPatch(patch, region)
	if err != nil {
		return nil, fmt.Errorf("failed to get ban trends: %w", err)
	}

	return &models.PatchTrends{
		Patch:          patch,
		Region:         region,
		AnalysisDate:   time.Now(),
		ChampionTrends: championTrends,
		ItemTrends:     itemTrends,
		BanTrends:      banTrends,
	}, nil
}

// DetectEmergingChampions identifies champions gaining popularity rapidly
func (m *MetaGameAnalyticsService) DetectEmergingChampions(days int, region string) ([]models.EmergingChampion, error) {
	log.Printf("🚀 Detecting emerging champions over last %d days in %s", days, region)
	
	query := `
		WITH current_period AS (
			SELECT champion_id, champion_name, 
				   COUNT(*) as current_picks,
				   AVG(CASE WHEN win = 1 THEN 1.0 ELSE 0.0 END) as current_winrate,
				   AVG((kills + assists) * 1.0 / NULLIF(deaths, 0)) as current_kda
			FROM matches 
			WHERE game_creation >= ? AND region = ?
			GROUP BY champion_id, champion_name
		),
		previous_period AS (
			SELECT champion_id, champion_name,
				   COUNT(*) as previous_picks,
				   AVG(CASE WHEN win = 1 THEN 1.0 ELSE 0.0 END) as previous_winrate
			FROM matches 
			WHERE game_creation >= ? AND game_creation < ? AND region = ?
			GROUP BY champion_id, champion_name
		)
		SELECT c.champion_id, c.champion_name,
			   c.current_picks, c.current_winrate, c.current_kda,
			   COALESCE(p.previous_picks, 0) as previous_picks,
			   COALESCE(p.previous_winrate, 0) as previous_winrate,
			   ((c.current_picks - COALESCE(p.previous_picks, 0)) * 1.0 / 
				NULLIF(COALESCE(p.previous_picks, 1), 0)) as pick_rate_change,
			   (c.current_winrate - COALESCE(p.previous_winrate, 0)) as winrate_change
		FROM current_period c
		LEFT JOIN previous_period p ON c.champion_id = p.champion_id
		WHERE c.current_picks >= 10
		ORDER BY pick_rate_change DESC, winrate_change DESC
		LIMIT 20
	`

	periodStart := time.Now().AddDate(0, 0, -days).Unix() * 1000
	previousPeriodStart := time.Now().AddDate(0, 0, -days*2).Unix() * 1000

	rows, err := m.db.Query(query, periodStart, region, previousPeriodStart, periodStart, region)
	if err != nil {
		return nil, fmt.Errorf("failed to query emerging champions: %w", err)
	}
	defer rows.Close()

	var emerging []models.EmergingChampion
	for rows.Next() {
		var champ models.EmergingChampion
		err := rows.Scan(
			&champ.ChampionID, &champ.ChampionName,
			&champ.CurrentPicks, &champ.CurrentWinRate, &champ.CurrentKDA,
			&champ.PreviousPicks, &champ.PreviousWinRate,
			&champ.PickRateChange, &champ.WinRateChange,
		)
		if err != nil {
			log.Printf("⚠️ Error scanning emerging champion: %v", err)
			continue
		}

		// Calculate emergence score
		champ.EmergenceScore = m.calculateEmergenceScore(champ)
		champ.TrendDirection = m.calculateTrendDirection(champ)
		emerging = append(emerging, champ)
	}

	log.Printf("✅ Found %d emerging champions", len(emerging))
	return emerging, nil
}

// AnalyzeTeamSynergies analyzes champion synergies and team compositions
func (m *MetaGameAnalyticsService) AnalyzeTeamSynergies(days int, region string) ([]models.TeamSynergy, error) {
	log.Printf("🤝 Analyzing team synergies over last %d days", days)

	query := `
		SELECT m1.champion_id as champ1_id, m1.champion_name as champ1_name,
			   m2.champion_id as champ2_id, m2.champion_name as champ2_name,
			   COUNT(*) as games_together,
			   AVG(CASE WHEN m1.win = 1 THEN 1.0 ELSE 0.0 END) as win_rate,
			   AVG(m1.kills + m1.assists) as avg_impact
		FROM matches m1
		JOIN matches m2 ON m1.match_id = m2.match_id 
			AND m1.team_id = m2.team_id 
			AND m1.champion_id < m2.champion_id
		WHERE m1.game_creation >= ? 
			AND m1.region = ? 
			AND m2.region = ?
		GROUP BY m1.champion_id, m1.champion_name, m2.champion_id, m2.champion_name
		HAVING games_together >= 10
		ORDER BY win_rate DESC, games_together DESC
		LIMIT 50
	`

	startTime := time.Now().AddDate(0, 0, -days).Unix() * 1000
	rows, err := m.db.Query(query, startTime, region, region)
	if err != nil {
		return nil, fmt.Errorf("failed to query team synergies: %w", err)
	}
	defer rows.Close()

	var synergies []models.TeamSynergy
	for rows.Next() {
		var synergy models.TeamSynergy
		err := rows.Scan(
			&synergy.Champion1ID, &synergy.Champion1Name,
			&synergy.Champion2ID, &synergy.Champion2Name,
			&synergy.GamesTogether, &synergy.WinRate, &synergy.AvgImpact,
		)
		if err != nil {
			log.Printf("⚠️ Error scanning synergy: %v", err)
			continue
		}

		synergy.SynergyScore = m.calculateSynergyScore(synergy)
		synergy.Confidence = math.Min(float64(synergy.GamesTogether)/50.0, 1.0)
		synergies = append(synergies, synergy)
	}

	log.Printf("✅ Found %d champion synergies", len(synergies))
	return synergies, nil
}

// TrackItemMeta analyzes item build patterns and meta shifts
func (m *MetaGameAnalyticsService) TrackItemMeta(days int, region string) (*models.ItemMeta, error) {
	log.Printf("📦 Tracking item meta over last %d days", days)

	// Get popular item builds
	itemBuilds, err := m.getPopularItemBuilds(days, region)
	if err != nil {
		return nil, fmt.Errorf("failed to get item builds: %w", err)
	}

	// Get item win rates
	itemWinRates, err := m.getItemWinRates(days, region)
	if err != nil {
		return nil, fmt.Errorf("failed to get item win rates: %w", err)
	}

	// Get trending items
	trendingItems, err := m.getTrendingItems(days, region)
	if err != nil {
		return nil, fmt.Errorf("failed to get trending items: %w", err)
	}

	return &models.ItemMeta{
		Region:        region,
		AnalysisPeriod: days,
		LastUpdated:   time.Now(),
		PopularBuilds: itemBuilds,
		ItemWinRates:  itemWinRates,
		TrendingItems: trendingItems,
	}, nil
}

// AnalyzeRankCorrelations analyzes correlations between rank and champion usage
func (m *MetaGameAnalyticsService) AnalyzeRankCorrelations(days int, region string) ([]models.RankCorrelation, error) {
	log.Printf("📊 Analyzing rank correlations over last %d days", days)

	query := `
		SELECT champion_id, champion_name, tier, rank_tier,
			   COUNT(*) as games_played,
			   AVG(CASE WHEN win = 1 THEN 1.0 ELSE 0.0 END) as win_rate,
			   AVG(kills + assists) as avg_impact
		FROM matches 
		WHERE game_creation >= ? 
			AND region = ? 
			AND tier IS NOT NULL
		GROUP BY champion_id, champion_name, tier, rank_tier
		HAVING games_played >= 5
		ORDER BY tier, win_rate DESC
	`

	startTime := time.Now().AddDate(0, 0, -days).Unix() * 1000
	rows, err := m.db.Query(query, startTime, region)
	if err != nil {
		return nil, fmt.Errorf("failed to query rank correlations: %w", err)
	}
	defer rows.Close()

	var correlations []models.RankCorrelation
	for rows.Next() {
		var corr models.RankCorrelation
		err := rows.Scan(
			&corr.ChampionID, &corr.ChampionName, &corr.Tier, &corr.RankTier,
			&corr.GamesPlayed, &corr.WinRate, &corr.AvgImpact,
		)
		if err != nil {
			log.Printf("⚠️ Error scanning rank correlation: %v", err)
			continue
		}

		corr.RankScore = m.calculateRankScore(corr)
		correlations = append(correlations, corr)
	}

	log.Printf("✅ Found %d rank correlations", len(correlations))
	return correlations, nil
}

// Private helper methods

func (m *MetaGameAnalyticsService) getChampionTrendsByPatch(patch, region string) ([]models.ChampionTrend, error) {
	query := `
		SELECT champion_id, champion_name,
			   COUNT(*) as total_picks,
			   AVG(CASE WHEN win = 1 THEN 1.0 ELSE 0.0 END) as win_rate,
			   AVG(kills + assists) as avg_impact
		FROM matches 
		WHERE game_version LIKE ? AND region = ?
		GROUP BY champion_id, champion_name
		HAVING total_picks >= 10
		ORDER BY total_picks DESC
		LIMIT 50
	`

	rows, err := m.db.Query(query, patch+"%", region)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var trends []models.ChampionTrend
	for rows.Next() {
		var trend models.ChampionTrend
		err := rows.Scan(&trend.ChampionID, &trend.ChampionName, &trend.TotalPicks, &trend.WinRate, &trend.AvgImpact)
		if err != nil {
			continue
		}
		trends = append(trends, trend)
	}

	return trends, nil
}

func (m *MetaGameAnalyticsService) getItemTrendsByPatch(patch, region string) ([]models.ItemTrend, error) {
	// This would require parsing item build data from match details
	// For now, returning mock data structure
	return []models.ItemTrend{}, nil
}

func (m *MetaGameAnalyticsService) getBanTrendsByPatch(patch, region string) ([]models.BanTrend, error) {
	// This would require ban data from match details
	// For now, returning mock data structure
	return []models.BanTrend{}, nil
}

func (m *MetaGameAnalyticsService) getPopularItemBuilds(days int, region string) ([]models.ItemBuild, error) {
	// This would require parsing item build sequences from match timeline
	// For now, returning empty slice
	return []models.ItemBuild{}, nil
}

func (m *MetaGameAnalyticsService) getItemWinRates(days int, region string) ([]models.ItemWinRate, error) {
	// This would require item analysis from match data
	// For now, returning empty slice
	return []models.ItemWinRate{}, nil
}

func (m *MetaGameAnalyticsService) getTrendingItems(days int, region string) ([]models.TrendingItem, error) {
	// This would require temporal item analysis
	// For now, returning empty slice
	return []models.TrendingItem{}, nil
}

func (m *MetaGameAnalyticsService) calculateEmergenceScore(champ models.EmergingChampion) float64 {
	// Score based on pick rate increase and win rate
	pickRateWeight := math.Min(champ.PickRateChange/2.0, 1.0)  // Cap at 200% increase
	winRateWeight := champ.WinRateChange * 10                    // 1% winrate = 10 points
	volumeWeight := math.Min(float64(champ.CurrentPicks)/100.0, 1.0) // Volume confidence
	
	return (pickRateWeight*0.4 + winRateWeight*0.4 + volumeWeight*0.2) * 100
}

func (m *MetaGameAnalyticsService) calculateTrendDirection(champ models.EmergingChampion) string {
	if champ.PickRateChange > 0.2 && champ.WinRateChange > 0 {
		return "strongly_rising"
	} else if champ.PickRateChange > 0.1 {
		return "rising"
	} else if champ.PickRateChange < -0.1 {
		return "declining"
	}
	return "stable"
}

func (m *MetaGameAnalyticsService) calculateSynergyScore(synergy models.TeamSynergy) float64 {
	// Base score from win rate above 50%
	baseScore := math.Max(0, (synergy.WinRate-0.5)*200) // 60% winrate = 20 points
	
	// Bonus for high impact
	impactBonus := math.Min(synergy.AvgImpact/20.0, 1.0) * 30 // Cap at 30 points
	
	// Confidence from sample size
	confidenceMultiplier := math.Min(float64(synergy.GamesTogether)/50.0, 1.0)
	
	return (baseScore + impactBonus) * confidenceMultiplier
}

func (m *MetaGameAnalyticsService) calculateRankScore(corr models.RankCorrelation) float64 {
	// Higher rank tiers get more weight for win rate
	tierWeight := 1.0
	switch corr.Tier {
	case "CHALLENGER", "GRANDMASTER", "MASTER":
		tierWeight = 2.0
	case "DIAMOND":
		tierWeight = 1.5
	case "PLATINUM", "EMERALD":
		tierWeight = 1.2
	}
	
	return corr.WinRate * tierWeight * math.Min(float64(corr.GamesPlayed)/20.0, 1.0)
}
