package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"lol-match-exporter/internal/models"
	"lol-match-exporter/internal/services"
)

// PatternHandler handles gameplay pattern analysis endpoints
type PatternHandler struct {
	PatternService *services.PatternDetectionService
}

// NewPatternHandler creates a new pattern handler
func NewPatternHandler(patternService *services.PatternDetectionService) *PatternHandler {
	return &PatternHandler{
		PatternService: patternService,
	}
}

// GetVictoryPatterns returns patterns that lead to victories
// GET /api/patterns/victory
func (h *PatternHandler) GetVictoryPatterns(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	patterns, err := h.PatternService.DetectVictoryPatterns(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"victory_patterns": patterns,
			"total_patterns":   len(patterns),
		},
	})
}

// GetDefeatPatterns returns patterns that lead to defeats
// GET /api/patterns/defeat
func (h *PatternHandler) GetDefeatPatterns(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	patterns, err := h.PatternService.DetectDefeatPatterns(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"defeat_patterns": patterns,
			"total_patterns":  len(patterns),
		},
	})
}

// GetAllPatterns returns both victory and defeat patterns
// GET /api/patterns/all
func (h *PatternHandler) GetAllPatterns(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	victoryPatterns, err := h.PatternService.DetectVictoryPatterns(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get victory patterns: " + err.Error()})
		return
	}

	defeatPatterns, err := h.PatternService.DetectDefeatPatterns(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get defeat patterns: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"victory_patterns":     victoryPatterns,
			"defeat_patterns":      defeatPatterns,
			"total_victory":        len(victoryPatterns),
			"total_defeat":         len(defeatPatterns),
			"total_patterns":       len(victoryPatterns) + len(defeatPatterns),
		},
	})
}

// GetOptimalTiming returns optimal timing analysis
// GET /api/patterns/timing
func (h *PatternHandler) GetOptimalTiming(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	timingPatterns, err := h.PatternService.AnalyzeOptimalTiming(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"timing_patterns": timingPatterns,
			"total_patterns":  len(timingPatterns),
		},
	})
}

// GetPerformanceAnomalies returns detected performance anomalies
// GET /api/patterns/anomalies
func (h *PatternHandler) GetPerformanceAnomalies(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	anomalies, err := h.PatternService.DetectPerformanceAnomalies(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Categorize anomalies by severity
	criticalAnomalies := []interface{}{}
	highAnomalies := []interface{}{}
	mediumAnomalies := []interface{}{}
	lowAnomalies := []interface{}{}

	for _, anomaly := range anomalies {
		switch anomaly.Severity {
		case "critical":
			criticalAnomalies = append(criticalAnomalies, anomaly)
		case "high":
			highAnomalies = append(highAnomalies, anomaly)
		case "medium":
			mediumAnomalies = append(mediumAnomalies, anomaly)
		case "low":
			lowAnomalies = append(lowAnomalies, anomaly)
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"anomalies": gin.H{
				"critical": criticalAnomalies,
				"high":     highAnomalies,
				"medium":   mediumAnomalies,
				"low":      lowAnomalies,
			},
			"total_anomalies": len(anomalies),
			"summary": gin.H{
				"critical_count": len(criticalAnomalies),
				"high_count":     len(highAnomalies),
				"medium_count":   len(mediumAnomalies),
				"low_count":      len(lowAnomalies),
			},
		},
	})
}

// GetPlayStyle returns user's analyzed play style
// GET /api/patterns/playstyle
func (h *PatternHandler) GetPlayStyle(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	playStyle, err := h.PatternService.AnalyzePlayStyle(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    playStyle,
	})
}

// GetPatternSummary returns a comprehensive summary of all patterns
// GET /api/patterns/summary
func (h *PatternHandler) GetPatternSummary(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	// Get all pattern types
	victoryPatterns, _ := h.PatternService.DetectVictoryPatterns(userID.(int))
	defeatPatterns, _ := h.PatternService.DetectDefeatPatterns(userID.(int))
	timingPatterns, _ := h.PatternService.AnalyzeOptimalTiming(userID.(int))
	anomalies, _ := h.PatternService.DetectPerformanceAnomalies(userID.(int))
	playStyle, _ := h.PatternService.AnalyzePlayStyle(userID.(int))

	// Calculate pattern insights
	totalPatterns := len(victoryPatterns) + len(defeatPatterns) + len(timingPatterns)
	
	// Find most impactful patterns
	var mostImpactfulVictory, mostImpactfulDefeat interface{}
	highestVictoryImpact := 0.0
	highestDefeatImpact := 0.0

	for _, pattern := range victoryPatterns {
		if pattern.ImpactScore > highestVictoryImpact {
			highestVictoryImpact = pattern.ImpactScore
			mostImpactfulVictory = pattern
		}
	}

	for _, pattern := range defeatPatterns {
		if pattern.ImpactScore > highestDefeatImpact {
			highestDefeatImpact = pattern.ImpactScore
			mostImpactfulDefeat = pattern
		}
	}

	// Count anomalies by severity
	anomalyCounts := make(map[string]int)
	for _, anomaly := range anomalies {
		anomalyCounts[anomaly.Severity]++
	}

	summary := gin.H{
		"user_id": userID,
		"analysis_overview": gin.H{
			"total_patterns":         totalPatterns,
			"victory_patterns_count": len(victoryPatterns),
			"defeat_patterns_count":  len(defeatPatterns),
			"timing_patterns_count":  len(timingPatterns),
			"anomalies_count":        len(anomalies),
			"has_playstyle_analysis": playStyle != nil,
		},
		"key_insights": gin.H{
			"most_impactful_victory_pattern": mostImpactfulVictory,
			"most_impactful_defeat_pattern":  mostImpactfulDefeat,
			"primary_playstyle":              nil,
			"playstyle_confidence":           0.0,
		},
		"anomaly_summary": anomalyCounts,
		"recommendations": h.generatePatternRecommendations(victoryPatterns, defeatPatterns, anomalies, playStyle),
	}

	if playStyle != nil {
		summary["key_insights"].(gin.H)["primary_playstyle"] = playStyle.PrimaryStyle
		summary["key_insights"].(gin.H)["playstyle_confidence"] = playStyle.Confidence
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    summary,
	})
}

// GetPatternTrends returns pattern evolution over time
// GET /api/patterns/trends?days=30
func (h *PatternHandler) GetPatternTrends(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 7 || days > 90 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "days must be between 7 and 90"})
		return
	}

	// For now, return current patterns with trend placeholders
	// This would require temporal pattern analysis in a real implementation
	victoryPatterns, _ := h.PatternService.DetectVictoryPatterns(userID.(int))
	defeatPatterns, _ := h.PatternService.DetectDefeatPatterns(userID.(int))

	trends := gin.H{
		"analysis_period": days,
		"pattern_trends": gin.H{
			"victory_patterns": gin.H{
				"current":     victoryPatterns,
				"trend":       "stable", // Would calculate actual trend
				"change_rate": 0.0,     // Would calculate actual change
			},
			"defeat_patterns": gin.H{
				"current":     defeatPatterns,
				"trend":       "stable",
				"change_rate": 0.0,
			},
		},
		"pattern_evolution": []gin.H{
			{
				"date":           "recent",
				"pattern_count":  len(victoryPatterns) + len(defeatPatterns),
				"dominant_type":  h.getDominantPatternType(victoryPatterns, defeatPatterns),
			},
		},
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    trends,
	})
}

// Private helper methods

func (h *PatternHandler) generatePatternRecommendations(victoryPatterns, defeatPatterns []models.GamePattern, anomalies []models.PerformanceAnomaly, playStyle *models.PlayStyle) []string {
	var recommendations []string

	// Add recommendations based on patterns
	if len(victoryPatterns) > 0 {
		recommendations = append(recommendations, "Focus on replicating your victory patterns")
	}

	if len(defeatPatterns) > 0 {
		recommendations = append(recommendations, "Work on avoiding your common defeat patterns")
	}

	if len(anomalies) > 0 {
		recommendations = append(recommendations, "Address detected performance anomalies")
	}

	if playStyle != nil {
		recommendations = append(recommendations, "Optimize your play style for better consistency")
	}

	if len(recommendations) == 0 {
		recommendations = append(recommendations, "Continue analyzing your gameplay for patterns")
	}

	return recommendations
}

func (h *PatternHandler) getDominantPatternType(victoryPatterns, defeatPatterns []models.GamePattern) string {
	if len(victoryPatterns) > len(defeatPatterns) {
		return "victory"
	} else if len(defeatPatterns) > len(victoryPatterns) {
		return "defeat"
	}
	return "balanced"
}
