package handlers

import (
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	
	"lol-match-exporter/internal/services"
)

// ExportHandler gère les endpoints d'export avancé
type ExportHandler struct {
	exportService     *services.ExportService
	webhookService    *services.WebhookService
	googleSheetsService *services.GoogleSheetsService
}

// NewExportHandler crée une nouvelle instance du handler d'export
func NewExportHandler(exportService *services.ExportService, webhookService *services.WebhookService, googleSheetsService *services.GoogleSheetsService) *ExportHandler {
	return &ExportHandler{
		exportService:     exportService,
		webhookService:    webhookService,
		googleSheetsService: googleSheetsService,
	}
}

// ExportAdvanced gère l'export avancé avec multiple formats
func (eh *ExportHandler) ExportAdvanced(c *gin.Context) {
	_, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	var request struct {
		Format        services.ExportFormat  `json:"format" binding:"required"`
		Filter        services.ExportFilter  `json:"filter"`
		Columns       []string               `json:"columns"`
		Compression   bool                   `json:"compression"`
		Metadata      bool                   `json:"metadata"`
		WebhookURL    string                 `json:"webhook_url,omitempty"`
		GoogleSheetID string                 `json:"google_sheet_id,omitempty"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Créer les options d'export
	options := services.ExportOptions{
		Format:      request.Format,
		Filter:      request.Filter,
		Columns:     request.Columns,
		Compression: request.Compression,
		Metadata:    request.Metadata,
	}

	// Valider les options
	if err := eh.exportService.ValidateOptions(options); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// TODO: Récupérer les vraies données depuis la base
	matches := []services.MatchData{} // Placeholder

	// Exporter selon le format demandé
	switch request.Format {
	case services.FormatJSON, services.FormatCSV, services.FormatExcel:
		filepath, err := eh.exportService.ExportMatches(matches, options)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}

		result := gin.H{
			"success":     true,
			"format":      request.Format,
			"filepath":    filepath,
			"record_count": len(matches),
			"exported_at": time.Now(),
		}

		// Envoyer webhook si configuré
		if request.WebhookURL != "" {
			go eh.sendExportNotification(request.WebhookURL, result)
		}

		c.JSON(http.StatusOK, result)

	default:
		c.JSON(http.StatusBadRequest, gin.H{"error": "Unsupported export format"})
	}
}

// ExportToGoogleSheets exporte vers Google Sheets
func (eh *ExportHandler) ExportToGoogleSheets(c *gin.Context) {
	_, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	var request struct {
		SpreadsheetID string                `json:"spreadsheet_id" binding:"required"`
		SheetType     string                `json:"sheet_type"` // "matches", "stats", "chart"
		Filter        services.ExportFilter `json:"filter"`
		AutoUpdate    bool                  `json:"auto_update"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Valider l'ID de feuille
	if err := services.ValidateGoogleSheetsID(request.SpreadsheetID); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Vérifier l'accès à la feuille
	if err := eh.googleSheetsService.ValidateSpreadsheetAccess(request.SpreadsheetID); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "Cannot access Google Sheet. Please check the ID and sharing permissions.",
		})
		return
	}

	// TODO: Récupérer les vraies données
	matches := []services.MatchData{} // Placeholder
	
	var err error
	switch request.SheetType {
	case "matches":
		options := services.ExportOptions{Filter: request.Filter}
		err = eh.googleSheetsService.ExportToGoogleSheets(request.SpreadsheetID, matches, options)
	case "stats":
		// TODO: Générer les vraies statistiques
		stats := services.StatsUpdate{
			RiotID:        "Player",
			RiotTag:       "TAG",
			Region:        "euw1",
			TotalMatches:  len(matches),
			WinRate:       60.0,
			Timestamp:     time.Now(),
		}
		err = eh.googleSheetsService.CreateStatsSheet(request.SpreadsheetID, stats)
	case "chart":
		err = eh.googleSheetsService.CreatePerformanceChart(request.SpreadsheetID, matches)
	case "dashboard":
		err = eh.googleSheetsService.CreateAutoUpdateSheet(request.SpreadsheetID)
	default:
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid sheet type"})
		return
	}

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	sheetURL := "https://docs.google.com/spreadsheets/d/" + request.SpreadsheetID
	
	c.JSON(http.StatusOK, gin.H{
		"success":       true,
		"spreadsheet_id": request.SpreadsheetID,
		"sheet_url":     sheetURL,
		"sheet_type":    request.SheetType,
		"record_count":  len(matches),
		"exported_at":   time.Now(),
	})
}

// SendWebhook envoie des statistiques via webhook
func (eh *ExportHandler) SendWebhook(c *gin.Context) {
	_, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	var request struct {
		WebhookURL  string `json:"webhook_url" binding:"required"`
		Type        string `json:"type"`        // "discord", "slack", "generic"
		MessageType string `json:"message_type"` // "stats", "match", "test"
		MatchID     string `json:"match_id,omitempty"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Valider l'URL du webhook
	if err := eh.webhookService.ValidateWebhookURL(request.WebhookURL); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var err error
	
	switch request.MessageType {
	case "test":
		isDiscord := request.Type == "discord"
		err = eh.webhookService.TestWebhook(request.WebhookURL, isDiscord)
		
	case "stats":
		// TODO: Récupérer les vraies statistiques utilisateur
		stats := services.StatsUpdate{
			PlayerName:      "Test Player",
			RiotID:          "TestPlayer",
			RiotTag:         "EUW",
			Region:          "euw1",
			TotalMatches:    100,
			RecentMatches:   10,
			WinRate:         65.5,
			RecentWinRate:   70.0,
			Rank:            "Gold II",
			LP:              45,
			MainChampion:    "Jinx",
			LastMatchResult: "Victory",
			Timestamp:       time.Now(),
		}
		
		if request.Type == "discord" {
			err = eh.webhookService.SendDiscordWebhook(request.WebhookURL, stats)
		} else {
			err = eh.webhookService.SendSlackWebhook(request.WebhookURL, stats)
		}
		
	case "match":
		if request.MatchID == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Match ID required for match notifications"})
			return
		}
		
		// TODO: Récupérer les vraies données de match
		matchData := services.MatchData{
			MatchID:      request.MatchID,
			GameCreation: time.Now(),
			ChampionName: "Jinx",
			GameMode:     "Ranked Solo",
			Win:          true,
			Kills:        12,
			Deaths:       3,
			Assists:      8,
			KDA:          6.67,
			GameDuration: 1847,
			Role:         "ADC",
			Lane:         "BOTTOM",
			Gold:         18500,
			Damage:       45000,
			Vision:       25,
		}
		
		err = eh.webhookService.SendMatchNotification(request.WebhookURL, matchData, request.Type == "discord")
		
	default:
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid message type"})
		return
	}

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"success": false,
			"error":   err.Error(),
		})
		return
	}

	webhookInfo := eh.webhookService.GetWebhookInfo(request.WebhookURL)
	
	c.JSON(http.StatusOK, gin.H{
		"success":      true,
		"webhook_type": request.Type,
		"message_type": request.MessageType,
		"webhook_info": webhookInfo,
		"sent_at":      time.Now(),
	})
}

// GetExportFormats retourne les formats d'export supportés
func (eh *ExportHandler) GetExportFormats(c *gin.Context) {
	formats := eh.exportService.GetSupportedFormats()
	
	formatDetails := make([]gin.H, len(formats))
	for i, format := range formats {
		formatDetails[i] = gin.H{
			"format":      format,
			"name":        eh.getFormatName(format),
			"description": eh.getFormatDescription(format),
			"extension":   string(format),
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"formats": formatDetails,
		"count":   len(formats),
	})
}

// GetExportHistory retourne l'historique des exports
func (eh *ExportHandler) GetExportHistory(c *gin.Context) {
	_, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User not authenticated"})
		return
	}

	// TODO: Implémenter l'historique réel des exports
	history := []gin.H{
		{
			"id":           1,
			"format":       "json",
			"created_at":   time.Now().Add(-24 * time.Hour),
			"record_count": 50,
			"file_size":    "125KB",
			"status":       "completed",
		},
		{
			"id":           2,
			"format":       "xlsx",
			"created_at":   time.Now().Add(-48 * time.Hour),
			"record_count": 75,
			"file_size":    "45KB",
			"status":       "completed",
		},
	}

	c.JSON(http.StatusOK, gin.H{
		"exports": history,
		"count":   len(history),
	})
}

// ValidateWebhook valide une URL de webhook
func (eh *ExportHandler) ValidateWebhook(c *gin.Context) {
	var request struct {
		WebhookURL string `json:"webhook_url" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := eh.webhookService.ValidateWebhookURL(request.WebhookURL); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"valid": false,
			"error": err.Error(),
		})
		return
	}

	webhookInfo := eh.webhookService.GetWebhookInfo(request.WebhookURL)
	
	c.JSON(http.StatusOK, gin.H{
		"valid":        true,
		"webhook_info": webhookInfo,
	})
}

// GetIntegrationStatus retourne le statut des intégrations
func (eh *ExportHandler) GetIntegrationStatus(c *gin.Context) {
	status := gin.H{
		"export_service": gin.H{
			"status":           "active",
			"supported_formats": eh.exportService.GetSupportedFormats(),
		},
		"webhook_service": gin.H{
			"status":            "active",
			"supported_platforms": []string{"discord", "slack", "generic"},
		},
		"google_sheets_service": gin.H{
			"status": "active",
			"features": []string{"export", "live_updates", "charts", "dashboard"},
		},
	}

	c.JSON(http.StatusOK, status)
}

// Méthodes utilitaires

func (eh *ExportHandler) getFormatName(format services.ExportFormat) string {
	switch format {
	case services.FormatCSV:
		return "Comma Separated Values"
	case services.FormatJSON:
		return "JavaScript Object Notation"
	case services.FormatParquet:
		return "Apache Parquet"
	case services.FormatExcel:
		return "Microsoft Excel"
	default:
		return string(format)
	}
}

func (eh *ExportHandler) getFormatDescription(format services.ExportFormat) string {
	switch format {
	case services.FormatCSV:
		return "Simple comma-separated format, compatible with Excel and most tools"
	case services.FormatJSON:
		return "Structured format with metadata, ideal for APIs and advanced analysis"
	case services.FormatParquet:
		return "Columnar format optimized for big data analytics (Pandas, Spark)"
	case services.FormatExcel:
		return "Native Excel format with formatting and multiple sheets"
	default:
		return "Export format"
	}
}

func (eh *ExportHandler) sendExportNotification(webhookURL string, result gin.H) {
	// Envoyer une notification d'export terminé
	message := fmt.Sprintf("Export completed: %s format, %v records", 
		result["format"], result["record_count"])
	
	payload := map[string]interface{}{
		"text":    message,
		"result":  result,
		"timestamp": time.Now(),
	}
	
	eh.webhookService.SendGenericWebhook(webhookURL, payload)
}
