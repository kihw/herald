package handlers

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"lol-match-exporter/internal/services"
)

// MetaGameHandler handles meta-game analytics endpoints
type MetaGameHandler struct {
	MetaGameService *services.MetaGameAnalyticsService
	PredictionService *services.PredictionService
}

// NewMetaGameHandler creates a new meta-game handler
func NewMetaGameHandler(metaService *services.MetaGameAnalyticsService, predictionService *services.PredictionService) *MetaGameHandler {
	return &MetaGameHandler{
		MetaGameService:   metaService,
		PredictionService: predictionService,
	}
}

// GetPatchTrends returns trends for a specific game patch
// GET /api/meta/patch-trends?patch=14.1&region=euw1
func (h *MetaGameHandler) GetPatchTrends(c *gin.Context) {
	patch := c.Query("patch")
	if patch == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "patch parameter is required"})
		return
	}

	region := c.DefaultQuery("region", "euw1")

	trends, err := h.MetaGameService.AnalyzePatchTrends(patch, region)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    trends,
	})
}

// GetEmergingChampions returns rapidly rising champions
// GET /api/meta/emerging-champions?days=14&region=euw1
func (h *MetaGameHandler) GetEmergingChampions(c *gin.Context) {
	daysStr := c.DefaultQuery("days", "14")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 1 || days > 90 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "days must be between 1 and 90"})
		return
	}

	region := c.DefaultQuery("region", "euw1")

	emerging, err := h.MetaGameService.DetectEmergingChampions(days, region)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"emerging_champions": emerging,
			"analysis_period":    days,
			"region":            region,
		},
	})
}

// GetTeamSynergies returns champion synergy analysis
// GET /api/meta/team-synergies?days=30&region=euw1
func (h *MetaGameHandler) GetTeamSynergies(c *gin.Context) {
	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 7 || days > 90 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "days must be between 7 and 90"})
		return
	}

	region := c.DefaultQuery("region", "euw1")

	synergies, err := h.MetaGameService.AnalyzeTeamSynergies(days, region)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"synergies":       synergies,
			"analysis_period": days,
			"region":         region,
		},
	})
}

// GetItemMeta returns item meta analysis
// GET /api/meta/items?days=30&region=euw1
func (h *MetaGameHandler) GetItemMeta(c *gin.Context) {
	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 7 || days > 90 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "days must be between 7 and 90"})
		return
	}

	region := c.DefaultQuery("region", "euw1")

	itemMeta, err := h.MetaGameService.TrackItemMeta(days, region)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    itemMeta,
	})
}

// GetRankCorrelations returns rank correlation analysis
// GET /api/meta/rank-correlations?days=30&region=euw1
func (h *MetaGameHandler) GetRankCorrelations(c *gin.Context) {
	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 7 || days > 90 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "days must be between 7 and 90"})
		return
	}

	region := c.DefaultQuery("region", "euw1")

	correlations, err := h.MetaGameService.AnalyzeRankCorrelations(days, region)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"rank_correlations": correlations,
			"analysis_period":   days,
			"region":           region,
		},
	})
}

// PredictPerformance generates performance predictions
// GET /api/predictions/performance?type=winrate&days=30
func (h *MetaGameHandler) PredictPerformance(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	predictionType := c.DefaultQuery("type", "winrate")
	if predictionType != "winrate" && predictionType != "kda" && predictionType != "cs_per_min" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "type must be winrate, kda, or cs_per_min"})
		return
	}

	daysStr := c.DefaultQuery("days", "30")
	days, err := strconv.Atoi(daysStr)
	if err != nil || days < 7 || days > 90 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "days must be between 7 and 90"})
		return
	}

	prediction, err := h.PredictionService.PredictPerformance(userID.(int), days, predictionType)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    prediction,
	})
}

// RecommendChampions recommends optimal champions for team composition
// POST /api/predictions/champion-recommendations
// Body: {"team_composition": [64, 92], "enemy_composition": [11, 89]}
func (h *MetaGameHandler) RecommendChampions(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	var request struct {
		TeamComposition  []int `json:"team_composition"`
		EnemyComposition []int `json:"enemy_composition"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request format"})
		return
	}

	recommendations, err := h.PredictionService.RecommendOptimalChampions(
		userID.(int), request.TeamComposition, request.EnemyComposition,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"recommendations":    recommendations,
			"team_composition":   request.TeamComposition,
			"enemy_composition":  request.EnemyComposition,
		},
	})
}

// PredictMatchOutcome predicts match outcome in real-time
// POST /api/predictions/match-outcome
// Body: {"team_composition": [64, 92, 11, 89, 45], "enemy_composition": [1, 12, 13, 14, 15]}
func (h *MetaGameHandler) PredictMatchOutcome(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	var request struct {
		TeamComposition  []int `json:"team_composition" binding:"required"`
		EnemyComposition []int `json:"enemy_composition" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Both team compositions are required"})
		return
	}

	if len(request.TeamComposition) != 5 || len(request.EnemyComposition) != 5 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Both teams must have exactly 5 champions"})
		return
	}

	prediction, err := h.PredictionService.PredictMatchOutcome(
		userID.(int), request.TeamComposition, request.EnemyComposition,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    prediction,
	})
}

// GenerateImprovementRoadmap creates personalized improvement plan
// POST /api/predictions/improvement-roadmap
// Body: {"target_level": "Platinum"}
func (h *MetaGameHandler) GenerateImprovementRoadmap(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	var request struct {
		TargetLevel string `json:"target_level" binding:"required"`
	}

	if err := c.ShouldBindJSON(&request); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "target_level is required"})
		return
	}

	validLevels := []string{"Iron", "Bronze", "Silver", "Gold", "Platinum", "Emerald", "Diamond", "Master", "Grandmaster", "Challenger"}
	isValid := false
	for _, level := range validLevels {
		if strings.EqualFold(request.TargetLevel, level) {
			request.TargetLevel = level // Normalize case
			isValid = true
			break
		}
	}

	if !isValid {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid target level"})
		return
	}

	roadmap, err := h.PredictionService.GenerateImprovementRoadmap(userID.(int), request.TargetLevel)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    roadmap,
	})
}

// DetectPlateau detects if user has hit a progression plateau
// GET /api/predictions/plateau-detection
func (h *MetaGameHandler) DetectPlateau(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "User ID not found"})
		return
	}

	plateau, err := h.PredictionService.DetectProgressionPlateau(userID.(int))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	if plateau == nil {
		c.JSON(http.StatusOK, gin.H{
			"success": true,
			"data": gin.H{
				"plateau_detected": false,
				"message":         "No plateau detected - performance is progressing normally",
			},
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"plateau_detected": true,
			"plateau_info":     plateau,
		},
	})
}

// GetAdvancedAnalytics returns comprehensive meta and prediction analytics
// GET /api/meta/advanced-analytics?region=euw1
func (h *MetaGameHandler) GetAdvancedAnalytics(c *gin.Context) {
	region := c.DefaultQuery("region", "euw1")
	days := 30 // Standard analysis period

	// Get emerging champions
	emerging, _ := h.MetaGameService.DetectEmergingChampions(days, region)

	// Get team synergies (top 20)
	synergies, _ := h.MetaGameService.AnalyzeTeamSynergies(days, region)
	if len(synergies) > 20 {
		synergies = synergies[:20]
	}

	// Get rank correlations
	correlations, _ := h.MetaGameService.AnalyzeRankCorrelations(days, region)

	// Combine all analytics
	analytics := gin.H{
		"region":             region,
		"analysis_period":    days,
		"emerging_champions": emerging,
		"top_synergies":      synergies,
		"rank_correlations":  correlations,
		"generated_at":       c.Request.Header.Get("Date"),
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    analytics,
	})
}

// GetMetaTrends returns trending meta information for dashboard
// GET /api/meta/trends
func (h *MetaGameHandler) GetMetaTrends(c *gin.Context) {
	region := c.DefaultQuery("region", "euw1")
	
	// Get recent emerging champions (last 7 days vs previous 7 days)
	recentEmerging, _ := h.MetaGameService.DetectEmergingChampions(7, region)
	
	// Limit to top 10 most trending
	if len(recentEmerging) > 10 {
		recentEmerging = recentEmerging[:10]
	}

	// Get high synergy pairs (last 14 days)
	synergies, _ := h.MetaGameService.AnalyzeTeamSynergies(14, region)
	
	// Filter for high confidence synergies
	var highConfidenceSynergies []interface{}
	for _, synergy := range synergies {
		if synergy.Confidence > 0.7 && len(highConfidenceSynergies) < 8 {
			highConfidenceSynergies = append(highConfidenceSynergies, synergy)
		}
	}

	trends := gin.H{
		"trending_champions":     recentEmerging,
		"strong_synergies":       highConfidenceSynergies,
		"region":                region,
		"last_updated":          "now", // Would be actual timestamp in production
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    trends,
	})
}
