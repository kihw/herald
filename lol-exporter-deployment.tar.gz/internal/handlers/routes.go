package handlers

import (
	"github.com/gin-gonic/gin"
	
	"lol-match-exporter/internal/services"
)

// SetupRoutes configure toutes les routes de l'application
func SetupRoutes(
	router *gin.Engine,
	matchHandler *MatchHandler,
	exportHandler *ExportHandler,
	analyticsHandler *AnalyticsHandler,
) {
	// Middleware CORS pour permettre les requêtes cross-origin
	router.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Authorization, X-Requested-With")
		
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		
		c.Next()
	})

	// Middleware d'authentification basique (à remplacer par JWT en prod)
	authMiddleware := func(c *gin.Context) {
		// Pour l'instant, on simule un utilisateur authentifié
		c.Set("user_id", "test-user")
		c.Next()
	}

	// Routes publiques
	public := router.Group("/api/v1")
	{
		public.GET("/health", func(c *gin.Context) {
			c.JSON(200, gin.H{
				"status":  "healthy",
				"version": "2.0.0",
				"phase":   "Phase 2 - Export & Integration",
			})
		})

		public.GET("/status", func(c *gin.Context) {
			c.JSON(200, gin.H{
				"status":    "operational",
				"services": gin.H{
					"export":        "active",
					"webhooks":      "active", 
					"google_sheets": "active",
					"analytics":     "active",
				},
			})
		})
	}

	// Routes authentifiées
	auth := router.Group("/api/v1")
	auth.Use(authMiddleware)
	{
		// === ROUTES EXISTANTES (Matches de base) ===
		
		// Gestion des matches
		auth.GET("/matches", matchHandler.GetMatches)
		auth.POST("/matches/fetch", matchHandler.FetchMatches)
		auth.GET("/matches/:id", matchHandler.GetMatch)
		auth.DELETE("/matches/:id", matchHandler.DeleteMatch)
		auth.POST("/matches/batch-delete", matchHandler.BatchDeleteMatches)

		// Export basique (conservé pour compatibilité)
		auth.POST("/export", matchHandler.ExportMatches)
		
		// === NOUVELLES ROUTES PHASE 1 (Analytics Avancé) ===
		
		// Meta-game Analytics
		auth.GET("/analytics/metagame/champions", analyticsHandler.GetChampionMetrics)
		auth.GET("/analytics/metagame/items", analyticsHandler.GetItemMetrics) 
		auth.GET("/analytics/metagame/trends", analyticsHandler.GetMetaTrends)
		auth.GET("/analytics/metagame/winrates", analyticsHandler.GetWinRateAnalysis)
		auth.GET("/analytics/metagame/synergies", analyticsHandler.GetChampionSynergies)
		auth.GET("/analytics/metagame/counters", analyticsHandler.GetChampionCounters)

		// Predictions ML
		auth.POST("/analytics/predictions/performance", analyticsHandler.PredictPerformance)
		auth.POST("/analytics/predictions/match-outcome", analyticsHandler.PredictMatchOutcome)
		auth.POST("/analytics/predictions/champion-suggestions", analyticsHandler.GetChampionSuggestions)
		auth.GET("/analytics/predictions/models", analyticsHandler.GetModelInfo)

		// Pattern Detection  
		auth.GET("/analytics/patterns/gameplay", analyticsHandler.DetectGameplayPatterns)
		auth.GET("/analytics/patterns/builds", analyticsHandler.DetectBuildPatterns)
		auth.GET("/analytics/patterns/performance", analyticsHandler.DetectPerformancePatterns)
		auth.GET("/analytics/patterns/temporal", analyticsHandler.DetectTemporalPatterns)

		// Statistiques avancées
		auth.GET("/analytics/stats/advanced", analyticsHandler.GetAdvancedStats)
		auth.GET("/analytics/stats/comparison", analyticsHandler.CompareStats)
		auth.GET("/analytics/stats/ranking", analyticsHandler.GetRankingAnalysis)
		auth.GET("/analytics/stats/progression", analyticsHandler.GetProgressionAnalysis)

		// Rapports et insights
		auth.GET("/analytics/reports/summary", analyticsHandler.GenerateSummaryReport)
		auth.GET("/analytics/reports/detailed", analyticsHandler.GenerateDetailedReport)
		auth.GET("/analytics/insights/recommendations", analyticsHandler.GetRecommendations)
		auth.GET("/analytics/insights/anomalies", analyticsHandler.DetectAnomalies)

		// === NOUVELLES ROUTES PHASE 2 (Export & Intégration) ===

		// Export Avancé
		exportRoutes := auth.Group("/export")
		{
			exportRoutes.GET("/formats", exportHandler.GetExportFormats)
			exportRoutes.POST("/advanced", exportHandler.ExportAdvanced) 
			exportRoutes.GET("/history", exportHandler.GetExportHistory)
		}

		// Google Sheets Integration
		googleSheetsRoutes := auth.Group("/integrations/google-sheets")
		{
			googleSheetsRoutes.POST("/export", exportHandler.ExportToGoogleSheets)
			googleSheetsRoutes.POST("/validate", func(c *gin.Context) {
				var request struct {
					SpreadsheetID string `json:"spreadsheet_id" binding:"required"`
				}
				if err := c.ShouldBindJSON(&request); err != nil {
					c.JSON(400, gin.H{"error": err.Error()})
					return
				}

				if err := services.ValidateGoogleSheetsID(request.SpreadsheetID); err != nil {
					c.JSON(400, gin.H{"valid": false, "error": err.Error()})
					return
				}

				c.JSON(200, gin.H{
					"valid": true,
					"url":   "https://docs.google.com/spreadsheets/d/" + request.SpreadsheetID,
				})
			})
		}

		// Webhook Integration
		webhookRoutes := auth.Group("/integrations/webhooks")
		{
			webhookRoutes.POST("/send", exportHandler.SendWebhook)
			webhookRoutes.POST("/validate", exportHandler.ValidateWebhook)
			webhookRoutes.POST("/test", func(c *gin.Context) {
				var request struct {
					WebhookURL string `json:"webhook_url" binding:"required"`
					Type       string `json:"type"` // "discord" or "slack"
				}
				if err := c.ShouldBindJSON(&request); err != nil {
					c.JSON(400, gin.H{"error": err.Error()})
					return
				}

				c.JSON(200, gin.H{
					"test":        "ok",
					"webhook_url": request.WebhookURL,
					"type":        request.Type,
				})
			})
		}

		// Statut des intégrations
		auth.GET("/integrations/status", exportHandler.GetIntegrationStatus)

		// === ROUTES DE DÉVELOPPEMENT ET DEBUG ===

		devRoutes := auth.Group("/dev")
		{
			devRoutes.GET("/test-data", func(c *gin.Context) {
				c.JSON(200, gin.H{
					"message": "Test data endpoint",
					"sample_match": gin.H{
						"match_id":     "EUW1_123456789",
						"champion":     "Jinx", 
						"result":       "Victory",
						"kda":          "12/3/8",
						"game_duration": 1847,
					},
				})
			})

			devRoutes.GET("/endpoints", func(c *gin.Context) {
				endpoints := []string{
					// Phase 1 - Analytics
					"GET /analytics/metagame/champions",
					"GET /analytics/metagame/trends", 
					"POST /analytics/predictions/performance",
					"GET /analytics/patterns/gameplay",
					
					// Phase 2 - Export & Integration
					"POST /export/advanced",
					"POST /integrations/google-sheets/export",
					"POST /integrations/webhooks/send",
					"GET /integrations/status",
				}
				
				c.JSON(200, gin.H{
					"total_endpoints": len(endpoints),
					"phase_1_analytics": 23,
					"phase_2_export": 8,
					"endpoints": endpoints,
				})
			})

			devRoutes.POST("/simulate", func(c *gin.Context) {
				var request struct {
					Type string `json:"type"` // "export", "webhook", "sheets"
				}
				if err := c.ShouldBindJSON(&request); err != nil {
					c.JSON(400, gin.H{"error": err.Error()})
					return
				}

				switch request.Type {
				case "export":
					c.JSON(200, gin.H{"simulation": "export", "status": "success"})
				case "webhook":
					c.JSON(200, gin.H{"simulation": "webhook", "status": "sent"})
				case "sheets":
					c.JSON(200, gin.H{"simulation": "google_sheets", "status": "updated"})
				default:
					c.JSON(400, gin.H{"error": "Invalid simulation type"})
				}
			})
		}
	}
}

// SetupCoreRoutes configure les routes de base (pour compatibilité)
func SetupCoreRoutes(router *gin.Engine, matchHandler *MatchHandler) {
	// Configuration basique pour le serveur existant
	router.GET("/", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"service": "LoL Match Exporter",
			"version": "2.0.0",
			"status":  "ready",
			"phase":   "Phase 2 Complete",
		})
	})

	// Routes compatibles avec l'ancienne API
	api := router.Group("/api")
	{
		api.GET("/matches", matchHandler.GetMatches)
		api.POST("/fetch-matches", matchHandler.FetchMatches)
		api.POST("/export-matches", matchHandler.ExportMatches)
	}
}
