package main

import (
	"log"
	"os"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	
	"lol-match-exporter/internal/handlers"
	"lol-match-exporter/internal/services"
)

func mainV2() {
	// Configuration par défaut
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	// Initialize services
	log.Println("Initializing services...")
	
	// Analytics Service (existant - placeholder)
	analyticsService := services.NewAnalyticsService(nil)
	
	// Export Service (Phase 2)
	exportService := services.NewExportService("./exports")
	
	// Webhook Service (Phase 2)
	webhookService := services.NewWebhookService()
	
	// Google Sheets Service (Phase 2)
	googleSheetsService := services.NewGoogleSheetsService("")

	// Initialize handlers
	log.Println("Initializing handlers...")
	matchHandler := handlers.NewMatchHandler()
	analyticsHandler := handlers.NewAnalyticsHandler(analyticsService)
	exportHandler := handlers.NewExportHandler(exportService, webhookService, googleSheetsService)

	// Initialize Gin router
	router := gin.Default()

	// Configure CORS
	config := cors.DefaultConfig()
	config.AllowAllOrigins = true
	config.AllowMethods = []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"}
	config.AllowHeaders = []string{"Origin", "Content-Type", "Authorization", "X-Requested-With"}
	router.Use(cors.New(config))

	// Configure routes
	log.Println("Setting up routes...")
	handlers.SetupRoutes(router, matchHandler, exportHandler, analyticsHandler)

	// Ajout d'une route de test pour validation
	router.GET("/test", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "LoL Match Exporter API - Phase 2 Complete",
			"version": "2.0.0",
			"status":  "operational",
			"features": gin.H{
				"phase_1_analytics": gin.H{
					"metagame_analysis":    true,
					"ml_predictions":       true,
					"pattern_detection":    true,
					"advanced_statistics":  true,
					"reports_insights":     true,
				},
				"phase_2_export": gin.H{
					"advanced_export":      true,
					"google_sheets":        true,
					"webhook_integration":  true,
					"multiple_formats":     true,
				},
			},
			"endpoints": gin.H{
				"analytics":    23,
				"export":       8,
				"integration":  5,
				"total":        36,
			},
		})
	})

	// Health check endpoint
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"status":    "healthy",
			"version":   "2.0.0",
			"phase":     "Phase 2 Complete",
			"services": gin.H{
				"database":      "connected",
				"analytics":     "active", 
				"export":        "active",
				"webhooks":      "active",
				"google_sheets": "active",
			},
		})
	})

	// Documentation endpoint
	router.GET("/docs", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"title": "LoL Match Exporter API Documentation",
			"version": "2.0.0",
			"description": "Advanced League of Legends match analytics and export platform",
			"phase_1_endpoints": []gin.H{
				{"group": "metagame", "endpoints": []string{
					"GET /api/v1/analytics/metagame/champions",
					"GET /api/v1/analytics/metagame/items",
					"GET /api/v1/analytics/metagame/trends",
					"GET /api/v1/analytics/metagame/winrates",
					"GET /api/v1/analytics/metagame/synergies",
					"GET /api/v1/analytics/metagame/counters",
				}},
				{"group": "predictions", "endpoints": []string{
					"POST /api/v1/analytics/predictions/performance",
					"POST /api/v1/analytics/predictions/match-outcome",
					"POST /api/v1/analytics/predictions/champion-suggestions",
					"GET /api/v1/analytics/predictions/models",
				}},
				{"group": "patterns", "endpoints": []string{
					"GET /api/v1/analytics/patterns/gameplay",
					"GET /api/v1/analytics/patterns/builds",
					"GET /api/v1/analytics/patterns/performance",
					"GET /api/v1/analytics/patterns/temporal",
				}},
				{"group": "advanced_stats", "endpoints": []string{
					"GET /api/v1/analytics/stats/advanced",
					"GET /api/v1/analytics/stats/comparison",
					"GET /api/v1/analytics/stats/ranking",
					"GET /api/v1/analytics/stats/progression",
				}},
				{"group": "reports", "endpoints": []string{
					"GET /api/v1/analytics/reports/summary",
					"GET /api/v1/analytics/reports/detailed",
					"GET /api/v1/analytics/insights/recommendations",
					"GET /api/v1/analytics/insights/anomalies",
				}},
			},
			"phase_2_endpoints": []gin.H{
				{"group": "export", "endpoints": []string{
					"GET /api/v1/export/formats",
					"POST /api/v1/export/advanced",
					"GET /api/v1/export/history",
				}},
				{"group": "integrations", "endpoints": []string{
					"POST /api/v1/integrations/google-sheets/export",
					"POST /api/v1/integrations/webhooks/send",
					"POST /api/v1/integrations/webhooks/validate",
					"GET /api/v1/integrations/status",
				}},
			},
		})
	})

	log.Printf("🚀 Server starting on port %s", port)
	log.Printf("📊 Phase 1: Advanced Analytics - 23 endpoints active")
	log.Printf("📤 Phase 2: Export & Integration - 8 endpoints active") 
	log.Printf("🔗 Total API endpoints: 36")
	log.Printf("📖 Documentation available at: http://localhost:%s/docs", port)
	log.Printf("🏥 Health check at: http://localhost:%s/health", port)
	log.Printf("🧪 Test endpoint at: http://localhost:%s/test", port)

	if err := router.Run(":" + port); err != nil {
		log.Fatal("Failed to start server:", err)
	}
}
